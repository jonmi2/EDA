package Colores;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Juego 
{
	Queue<Integer>[] jugadores = new Queue[6];
	Stack<Integer> mesa;
	
	
	 // Los colores de las fichas se representan por enteros ,donde las fichas negras vienen dadas por el 0, y el resto de jugadores tendr�n el color
	 // correspondiente a la posici�n del jugador (es decir, el jugador 1 tendr� fichas de valor 1, ...)	
	
	public Juego()
	{
		for (int i = 0; i <= 5; i++)
        {
            jugadores[i] = new LinkedList<Integer>();
            for (int c = 0; c <= 6; c++)
            {
                jugadores[i].add(i);
            }
        }
		mesa = new Stack<Integer>();
	}
	
	public int juego(ArrayList<Tirada> tiradas) 
	{
		// pre: n es el n�mero de fichas inicial de cada jugador �tiradas� tiene los valores de los dados durante una partida
		// post: el resultado es el n�mero del jugador ganador
		boolean ac=false;
		Iterator<Tirada> itr = tiradas.iterator();
		Tirada t;
		while(itr.hasNext() && !ac)
		{
			t=itr.next();
			if (t.dado1==6)
			{
				ac=true;
			}
			else if((t.dado1%2)==0)
			{
				if (!jugadores[(t.dado2)-1].isEmpty())
				{
					int f = jugadores[(t.dado2)-1].remove();
					mesa.push(f);
				}
			}
			else if((t.dado1%2)!=0)
			{
				if (!mesa.isEmpty())
				{
					int f = mesa.pop();
					jugadores[(t.dado2)-1].add(f);
				}
			}
		}
		
			
		//falta buscar el ganador
		int ganador=0;
		int cont=0;
		int max=0;
		for(int i=1; i<=5; i++) 
		{
			while(!jugadores[i].isEmpty())
			{
				int x=jugadores[i].remove();
				if(x==0)
				{	
					cont++;
				}
			}
			
			if(cont>max)
			{
				max=cont;
				ganador=i;
			}
		}
		
		return ganador;
	}
	
	 
}
