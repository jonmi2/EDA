package Colores;

import java.util.ArrayList;

public class Main 
{
	public static void main(String[] args)
	{
		Juego j = new Juego();
		
		ArrayList<Tirada> tiradas = new ArrayList<Tirada>();
 		Tirada t1= new Tirada(4,3);
 		Tirada t2= new Tirada(4,1);
 		Tirada t3= new Tirada(3,5);
 		Tirada t4= new Tirada(2,1);
 		Tirada t5= new Tirada(4,4);
 		Tirada t6= new Tirada(5,5);
 		Tirada t7= new Tirada(3,6);
 		Tirada t8= new Tirada(2,1);
 		Tirada t9= new Tirada(3,6);
 		Tirada t10= new Tirada(2,1);
 		Tirada t11= new Tirada(3,6);
 		Tirada t12= new Tirada(2,6);
 		Tirada t13= new Tirada(2,6);
 		Tirada t14= new Tirada(2,6);
 		Tirada t15= new Tirada(2,6);
 		
 		
 		tiradas.add(t1);
 		tiradas.add(t2);
 		tiradas.add(t3);
 		tiradas.add(t4);
 		tiradas.add(t5);
 		tiradas.add(t6);
 		tiradas.add(t7);
 		tiradas.add(t8);
 		tiradas.add(t9);
 		tiradas.add(t10);
 		tiradas.add(t11);
 		tiradas.add(t12);
 		tiradas.add(t13);
 		tiradas.add(t14);
 		tiradas.add(t15);
 		
 		
 		System.out.println(j.juego(tiradas));
 		
	}
}
