package Colores;

public class Tirada 
{
	int dado1;
	int dado2;
	
	public Tirada(int i1, int i2)
	{
		this.dado1=i1;
		this.dado2=i2;
	}
}
