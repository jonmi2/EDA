package bloques;

public class Bloque 
{
	int puntos;
	int salto; // valor entre 0 y 6
	String direccion; // �i� -> izquierda, �d� -> derecha 
	
	public Bloque (int pt, int s, String dir) 
	{
		this.puntos=pt;
		this.salto=s;
		this.direccion=dir;
	}
	
}
