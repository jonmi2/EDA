package bloques;

public class Main 
{
	public static void main(String[] args)
	{
		Juego j = new Juego();
		
		Bloque b1 = new Bloque(5,3,"d");
		Bloque b2 = new Bloque(5,3,"d");
		Bloque b3 = new Bloque(5,3,"d");
		j.tablero[0].push(b3);
		j.tablero[0].push(b2);
		j.tablero[0].push(b1);
		Bloque b4 = new Bloque(5,3,"d");
		Bloque b5 = new Bloque(5,1,"i");
		Bloque b6 = new Bloque(5,3,"d");
		j.tablero[1].push(b6);
		j.tablero[1].push(b5);
		j.tablero[1].push(b4);
		Bloque b7 = new Bloque(5,3,"d");
		Bloque b8 = new Bloque(5,3,"d");
		Bloque b9 = new Bloque(5,3,"d");
		j.tablero[2].push(b9);
		j.tablero[2].push(b8);
		j.tablero[2].push(b7);
		Bloque b10 = new Bloque(5,5,"d");
		Bloque b11 = new Bloque(5,0,"d");
		Bloque b12 = new Bloque(5,3,"i");
		j.tablero[3].push(b12);
		j.tablero[3].push(b11);
		j.tablero[3].push(b10);
		Bloque b13 = new Bloque(5,3,"i");
		Bloque b14 = new Bloque(5,3,"d");
		Bloque b15 = new Bloque(5,3,"d");
		j.tablero[4].push(b15);
		j.tablero[4].push(b14);
		j.tablero[4].push(b13);
		Bloque b16 = new Bloque(5,3,"i");
		Bloque b17 = new Bloque(5,2,"i");
		Bloque b18 = new Bloque(5,3,"d");
		j.tablero[5].push(b18);
		j.tablero[5].push(b17);
		j.tablero[5].push(b16);
		Bloque b19 = new Bloque(5,3,"d");
		Bloque b20 = new Bloque(5,3,"d");
		Bloque b21 = new Bloque(5,3,"d");
		j.tablero[6].push(b21);
		j.tablero[6].push(b20);
		j.tablero[6].push(b19);
		
		System.out.println(j.jugar());
		
	}
}
