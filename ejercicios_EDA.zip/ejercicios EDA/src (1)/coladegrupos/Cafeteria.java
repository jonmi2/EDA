package coladegrupos;

import java.util.LinkedList;
import java.util.Queue;

public class Cafeteria 
{
	Queue<Queue<Integer>> cola = null;
	
	
	public Cafeteria() 
	{
		this.cola=new LinkedList<Queue<Integer>>();
	}
	
	public void insertar (Integer elem)
	{
		boolean ad = false;
		Queue<Queue<Integer>> aux = new LinkedList<Queue<Integer>>();
		if (cola.isEmpty())
		{
			Queue<Integer> c1 = new LinkedList<Integer>();
			c1.add(elem);
			cola.add(c1);
		}
		else
		{
			while (!cola.isEmpty())
			{
				Queue<Integer> c1 = cola.remove();
				if (mismogrupo(elem, c1.peek()))
				{
					c1.add(elem);
					ad=true;
					aux.add(c1);
				}
				else
				{
					aux.add(c1);
				}
			}
			
			if (!ad)
			{
				Queue<Integer> c = new LinkedList<Integer>();
				c.add(elem);
				aux.add(c);
			}		
			cola=aux;
		}
	}
	
	public Integer borrar()
	{
		if (cola.isEmpty())
		{
			//System.out.println("no se borra ya que la cola vac�a");
			return null;
		}
		else
		{
			Integer borrado = cola.peek().remove();//cola.peek() DICE Q ES NULL
			if (cola.peek().isEmpty()) // si el primer grupo de la cola se queda vac�o tras eliminar el primero, se elimina esa cola.
			{
				cola.remove();
			}
			return borrado;	
		}
	}
	
	public boolean mismogrupo(int p1, int p2)
	{
		if ((p1==1 || p1==5 || p1==7) && ((p2==1 || p2==5 || p2==7)))
		{
			return true;
		}
		else if ((p1==2 || p1==4 || p1==8 || p1==10) && ((p2==2 || p2==4 || p2==8 || p2==10)))
		{
			return true;
		}
		else if ((p1==3 || p1==6 || p1==11) && ((p2==11 || p2==3 || p2==6)))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/*public void print()
	{
		if (cola.isEmpty())
		{
			System.out.println("Cola vac�a");
		}
		else
		{
			while (!cola.isEmpty())
			{
				Queue<Integer> c = cola.remove();
				while(!c.isEmpty())
				{
					Integer elem = c.remove();
					System.out.println(elem);
				}
			}
		}
	}*/
	
	
}
