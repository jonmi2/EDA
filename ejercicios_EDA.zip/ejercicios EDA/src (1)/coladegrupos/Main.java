package coladegrupos;

import java.util.LinkedList;
import java.util.Queue;

public class Main 
{
	public static void main(String[] args)
	{
		Cafeteria cafeteria = new Cafeteria();
		
		Queue<Integer> c1 = new LinkedList<Integer>();
		Queue<Integer> c2 = new LinkedList<Integer>();
		Queue<Integer> c3 = new LinkedList<Integer>();
		
		c1.add(1);
		c1.add(5);
		c1.add(7);
		c2.add(2);
		c2.add(8);
		c3.add(3);
		c3.add(6);
		
		
		Queue<Queue<Integer>> c =new LinkedList<Queue<Integer>>();
		c.add(c1);
		c.add(c2);
		c.add(c3);
		
		
		System.out.println(c.toString());
		System.out.println();
		
		System.out.println("ahora la primera cola");
		Queue<Integer> peek = c.peek();
		System.out.println(peek.toString());
		
		System.out.println();
		System.out.println("ahora la cafeteria");
		cafeteria.cola=c;
		System.out.println(cafeteria.cola.toString());

		
		cafeteria.borrar();
		System.out.println();
		System.out.println("despues de borrar el primero:");		
		System.out.println(cafeteria.cola.toString());
		
		
		System.out.println();
		System.out.println("despues de insertar el 4:");		
		cafeteria.insertar(4);
		System.out.println(cafeteria.cola.toString());
		
		
		Queue<Queue<Integer>> cn1 =new LinkedList<Queue<Integer>>();
		System.out.println();
		System.out.println("ahora cafeteria vacia");
		cafeteria.cola=cn1;
		System.out.println(cafeteria.cola.toString());

		
		cafeteria.borrar();
		System.out.println();
		System.out.println("despues de borrar el primero:");		
		System.out.println(cafeteria.cola.toString());
		
		
		System.out.println();
		System.out.println("despues de insertar el 4:");		
		cafeteria.insertar(4);
		System.out.println(cafeteria.cola.toString());
		
		System.out.println();
		System.out.println("despues de insertar el 5:");		
		cafeteria.insertar(5);
		System.out.println(cafeteria.cola.toString());
		
		System.out.println();
		System.out.println("despues de insertar el 6:");		
		cafeteria.insertar(6);
		System.out.println(cafeteria.cola.toString());
		
		System.out.println();
		System.out.println("despues de insertar el 11:");		
		cafeteria.insertar(11);
		System.out.println(cafeteria.cola.toString());
		
		System.out.println();
		System.out.println("despues de insertar el 20:");		
		cafeteria.insertar(20);
		System.out.println(cafeteria.cola.toString());
		
		System.out.println();
		System.out.println("despues de insertar el 11:");		
		cafeteria.insertar(11);
		System.out.println(cafeteria.cola.toString());
		
		System.out.println();
		System.out.println("despues de insertar el 1:");		
		cafeteria.insertar(1);
		System.out.println(cafeteria.cola.toString());
		
		System.out.println();
		System.out.println("despues de insertar el 8:");		
		cafeteria.insertar(8);
		System.out.println(cafeteria.cola.toString());
		
		
		
	}
}
