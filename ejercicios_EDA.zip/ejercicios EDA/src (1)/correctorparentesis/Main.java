package correctorparentesis;

public class Main 
{
	
	
	public static void main(String[] args)
	{
		Parentesis p = new Parentesis();
		String s1 = "([{[()]}])";
		String s2 = "[()]}])";
		String s3 = "[](){()}";
		String s4 = "(aa[e]{})";
		
		
		
		System.out.println("tiene que dar True y da....    ");
		System.out.println(p.corrector(s1));
		
		
		System.out.println("tiene que dar False y da....    ");
		System.out.println(p.corrector(s2));
		
		System.out.println("tiene que dar True y da....    ");
		System.out.println(p.corrector(s3));
		
		System.out.println("tiene que dar True y da....    ");
		System.out.println(p.corrector(s4));
	}
}
