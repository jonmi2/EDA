package correctorparentesis;

import java.util.Stack;

public class Parentesis 
{
	public Parentesis()
	{
		
	}
	
	public boolean corrector(String s) 
	{
		boolean error=false;		
		Stack<Character> p = new Stack<Character>();
		int i=0;
		while(i<s.length() && !error) 
		{
			char c = s.charAt(i);
			
			if(c=='(' || c=='{' || c=='[')
			{
				p.push(c);
			}
			else if (c==')' || c=='}' || c==']')
			{
				if (p.isEmpty())
				{
					error=true;
				}
				else
				{
					char n = p.pop();
					if (c==')' && n!='(' || c==']' && n!='[' || c=='}' && n!='{')
					{
						error=true;
					}
				}
			}
			else
			{
				
			}
			i++;
		}
		
		if (!error && p.isEmpty())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
}
