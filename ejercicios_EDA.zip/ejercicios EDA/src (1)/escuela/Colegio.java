package escuela;

import java.util.LinkedList;
import java.util.Queue;

public class Colegio 
{
	Queue<Queue<String>> alumnos= null; // cola de colas
	
	public Colegio()
	{
		this.alumnos=new LinkedList<Queue<String>>();
	}
	
	public void repartirRegalos(Queue<String> regalos)
	{
	 //post: los regalos se han repartido uno a uno, entregando el primer regalo a los alumnos del primer curso de la cola
	 // de alumnos, y as� sucesivamente. Se han escrito en la pantalla las asignaciones de regalos en forma de pares (alumno, regalo)
		if (regalos.isEmpty())
		{
			System.out.println("no hay regalos");
		}
		else
		{
			Queue<Queue<String>> cs = this.alumnos;
			while(!regalos.isEmpty())
			{
				Queue<String> curso = cs.remove();
				String r = regalos.remove();
				System.out.println();
				System.out.print("El regalo "+r+" ha sido dado a los alumnos: ");
				int i=0;
				while (i<curso.size())
				{
					String al = curso.remove();
					System.out.print(al+ " ");
					curso.add(al);
					i++;
				}
				cs.add(curso);
			}
		}
	}		
}
