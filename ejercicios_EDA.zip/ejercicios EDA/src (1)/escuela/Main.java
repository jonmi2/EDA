package escuela;

import java.util.LinkedList;
import java.util.Queue;

public class Main 
{
	public static void main(String[] args)
	{
		Colegio cole = new Colegio();
		Queue<String> rvac = new LinkedList<String>();
		Queue<String> reg = new LinkedList<String>();
		Queue<String> r2 = new LinkedList<String>();
		
		reg.add("r1");
		reg.add("r2");
		reg.add("r3");
		reg.add("r4");
		reg.add("r5");
		reg.add("r6");
		reg.add("r7");
		reg.add("r8");
		
		r2.add("r1");
		r2.add("r2");
		r2.add("r3");
		r2.add("r4");

		Queue<String> c1 = new LinkedList<String>();
		Queue<String> c2 = new LinkedList<String>();
		Queue<String> c3 = new LinkedList<String>();
		Queue<String> c4 = new LinkedList<String>();
		Queue<String> c5 = new LinkedList<String>();
		Queue<String> c6 = new LinkedList<String>();
		c1.add("a");
		c1.add("b");
		c1.add("c");
		c1.add("d");
		
		c2.add("e");
		c2.add("f");
		c2.add("g");
		c2.add("h");
		
		c3.add("i");
		c3.add("j");
		c3.add("k");
		c3.add("l");
		
		c4.add("m");
		c4.add("n");
		c4.add("o");
		c4.add("p");
		
		c5.add("q");
		c5.add("r");
		c5.add("s");
		c5.add("t");
		
		c6.add("w");
		c6.add("x");
		c6.add("y");
		c6.add("z");
		
		cole.alumnos.add(c1);
		cole.alumnos.add(c2);
		cole.alumnos.add(c3);
		cole.alumnos.add(c4);
		cole.alumnos.add(c5);
		cole.alumnos.add(c6);
		
		System.out.println("No hay regalosssssssss");
		cole.repartirRegalos(rvac);
		
		System.out.println();
		System.out.println("Ahora con mas regalos q cursos");
		cole.repartirRegalos(reg);

		
		cole.alumnos.remove();
		cole.alumnos.remove();
		cole.alumnos.remove();
		cole.alumnos.remove();
		cole.alumnos.remove();
		cole.alumnos.remove();
		
		
		cole.alumnos.add(c1);
		cole.alumnos.add(c2);
		cole.alumnos.add(c3);
		cole.alumnos.add(c4);
		cole.alumnos.add(c5);
		cole.alumnos.add(c6);
		
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("Ahora con menos regalos q cursos");
		cole.repartirRegalos(r2);
		
	
	}
}
