package impresoras;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class Impresoras 
{
	
	public Impresoras()
	{
	}
	
	public void procesarTrabajos(ArrayList<Peticion> lista)
	{
		//post: se ha escrito la situacion de las impresoras despues de procesar las peticiones
		Queue<Integer>[] impresoras= new Queue[6];
		for(int i=0; i<=5; i++)
		{
			impresoras[i]=new LinkedList<Integer>();
		}
		
		boolean apagon=false;
		for (Peticion p : lista)
		{
			if(!apagon)
			{
				if (p.tipoEv=='P')
				{
					impresoras[p.impresora].add(p.trabajo);
				}
				else if (p.tipoEv=='F')
				{
					impresoras[p.impresora].remove();
				}
				else if(p.tipoEv=='A')
				{
					apagon=true;
					for (int i=0; i<=5; i++) //for q recorre todas las impresoras
					{
						while(!impresoras[i].isEmpty()) //while q vac�a cada impresora
						{
							int x = impresoras[i].remove();
							impresoras[0].add(x);
						}
					}
				}
			}
			else
			{
				if (p.tipoEv=='P')
				{
					impresoras[0].add(p.trabajo);
				}
				else if (p.tipoEv=='F')
				{
					impresoras[0].remove();
				}
				else if (p.tipoEv=='S')
				{
					apagon=false;
				}
			}
		}
		
		
		for (int i = 0; i<=5; i++)//imprimir 
		{
			System.out.print("imp "+ i +" :");
			if (impresoras[i].isEmpty())
			{
				System.out.print("vac�a");
			}
			else
			{
				while(!impresoras[i].isEmpty()) //while q imprime cada impresora
				{			
					int x = impresoras[i].remove();
					System.out.print(x + " ");
					
				}
			}
			System.out.println("");
		}		
	}
	
}
