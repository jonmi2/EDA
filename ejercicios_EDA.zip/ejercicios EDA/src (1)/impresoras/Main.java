package impresoras;

import java.util.ArrayList;

public class Main 
{
	public static void main(String[] args)
	{
		Impresoras imp = new Impresoras();
		
		ArrayList<Peticion> lista = new ArrayList<Peticion>();
		Peticion p1 = new Peticion('P',2,1);
		Peticion p2 = new Peticion('P',3,2);
		Peticion p3 = new Peticion('P',5,3);
		Peticion p4 = new Peticion('P',5,4);
		Peticion p5 = new Peticion('F',5);
		Peticion p6 = new Peticion('P',2,5);
		Peticion p7 = new Peticion('A');
		Peticion p8 = new Peticion('F',0);
		Peticion p9 = new Peticion('P',1,6);
		Peticion p10 = new Peticion('S');
		Peticion p11 = new Peticion('P',1,7);
		
		lista.add(p1);
		lista.add(p2);
		lista.add(p3);
		lista.add(p4);
		lista.add(p5);
		lista.add(p6);
		lista.add(p7);
		lista.add(p8);
		lista.add(p9);
		lista.add(p10);
		lista.add(p11);
		
		imp.procesarTrabajos(lista);
		
	}
}
