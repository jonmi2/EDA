package impresoras;

public class Peticion 
{
	public Peticion(char tE, int imp, int tr)
	{
		this.tipoEv=tE;
		this.impresora=imp;
		this.trabajo=tr;
	}
	
	public Peticion(char tE, int imp)//F
	{
		this.tipoEv=tE;
		this.impresora=imp;
	}
	
	public Peticion(char tE)//A o S
	{
		this.tipoEv=tE;
	}
	
	
	Character tipoEv; //P(impresion), F(finalizacion del trabajo), A(apag�n) y S(subsanaci�n)
	
	Integer impresora; //numero de impresora (solo para eventos P o F)
	
	Integer trabajo; //numero del trabajo enviado (solo para evento P)
	
}
