package partidaDeCartas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Baraja
{
	private Carta[] cartas;
	
	
	private void inicializarBaraja() 
	{
        List<Carta> listaCartas = new ArrayList<>();
       
        for (int valor = 1; valor <= 10; valor++) 
        {
            listaCartas.add(new Carta("oros", valor));
            listaCartas.add(new Carta("copas", valor));
            listaCartas.add(new Carta("espadas", valor));
            listaCartas.add(new Carta("bastos", valor));
        }
        // Convertir la lista a un array
        cartas = listaCartas.toArray(new Carta[0]);
    }

    private void mezclarCartas() 
    {
        // Mezclar las cartas en orden aleatorio
        List<Carta> listaCartas = new ArrayList<>(List.of(cartas));
        Collections.shuffle(listaCartas);
        cartas = listaCartas.toArray(new Carta[0]);
    }
		
	
	public Baraja()// constructora
	{
		// postcondici�n: la baraja contiene 40 cartas en orden aleatorio
		inicializarBaraja();
        mezclarCartas();
	}
	
	
	public Iterator<Carta> iterador(){return new Iterator<Carta>();} // Devuelve un iterador para recorrer las cartas
	
		public class Iterator<T>
        {
            private int indice = 0;

            public Iterator()
            {
            	this.indice=0;
            }
            
            public boolean hasNext() 
            {
                return indice < cartas.length;
            }

            public Carta next() 
            {
                if (!hasNext()) 
                {
                    throw new java.util.NoSuchElementException();
                }
                return cartas[indice++];
            }
        }

	
}
