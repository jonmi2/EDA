package partidaDeCartas;

public class Bicola<T>
{
	public Bicola(); // constructora
	 // Inicializa la bicola (vac�a)
	 public boolean estaVacia();
	 // Indicar� si la bicola est� o no vac�a.
	 public void insertarIzq(T elemento);
	 // a�ade el elemento E por el extremo izquierdo de la bicola
	 public void insertarDer(T elemento);
	 // a�ade el elemento E por el extremo derecho de la bicola
	 public void eliminarIzq();
	 // borra el elemento del extremo izquierdo de la bicola
	 public void eliminarDer();
	 // borra el elemento del extremo derecho de la bicola
	 public T obtenerIzq();
	 // obtiene el elemento.del extremo izquierdo de la bicola
	 public T obtenerDer();
	 // obtiene el elemento.del extremo derecho de la bicola
}
