package partidaDeCartas;

public class Carta
{
	String palo; // oros, copas, espadas, espadas
	int valor; // valor entre 1 y 10
	
	public Carta(String p, int v) 
	{
		this.palo=p;
		this.valor=v;
	}
	
}
