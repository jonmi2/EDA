package partidaDeCartas;

import java.util.LinkedList;
import java.util.Queue;

public class Jugador 
{
	Queue<Carta> cola;
	
	public Jugador()
	{
		this.cola=new LinkedList<Carta>();
	}

	public void imprimircartas() 
	{
		while(!cola.isEmpty())
		{
			Carta c = cola.remove();
			String palo = c.palo;
			Integer valor =c.valor;
			System.out.println(valor + " de " + palo);
		}
	}
	
}
