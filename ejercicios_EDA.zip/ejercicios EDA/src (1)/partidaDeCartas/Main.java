package partidaDeCartas;

public class Main 
{
	public static void main(String[] args)
	{
		Partida p = new Partida();
		
		System.out.println("Cartas de j1: ");
		p.j1.imprimircartas();
		System.out.println(" ");
		System.out.println("Cartas de j2: ");
		p.j2.imprimircartas();
		System.out.println(" ");
		System.out.println("Cartas de j3: ");
		p.j3.imprimircartas();
		System.out.println(" ");
		System.out.println("Cartas de j4: ");
		p.j4.imprimircartas();
		
		System.out.println(" ");
		
		p.SimularPartida();
	}
}
