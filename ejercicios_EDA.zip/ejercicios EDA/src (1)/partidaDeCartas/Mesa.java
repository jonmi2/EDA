package partidaDeCartas;

import java.util.Stack;

public class Mesa 
{
	Stack<Carta> mesa;
	
	public Mesa()
	{
		this.mesa=new Stack<Carta>();
	}
}
