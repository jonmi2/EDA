package partidaDeCartas;

import partidaDeCartas.Baraja.Iterator;

public class Partida 
{
	Jugador j1;
	Jugador j2;
	Jugador j3;
	Jugador j4;
	
	Baraja baraja;
	
	Mesa mesa;
	
	public Partida()
	{
		this.mesa=new Mesa();
		this.baraja=new Baraja();
		this.j1=new Jugador();
		this.j2=new Jugador();
		this.j3=new Jugador();
		this.j4=new Jugador();
		
		Iterator<Carta> itr = baraja.iterador();
		
		Carta c;
		
		while(itr.hasNext())
		{
			for (int i=0; i<10; i++)
			{
				c=itr.next();
				j1.cola.add(c);
			}
			for (int i=0; i<10; i++)
			{
				c=itr.next();
				j2.cola.add(c);
			}
			for (int i=0; i<10; i++)
			{
				c=itr.next();
				j3.cola.add(c);
			}
			for (int i=0; i<10; i++)
			{
				c=itr.next();
				j4.cola.add(c);
			}
			
			
		}
	}
	
	
	public void SimularPartida()
	{
		while (!j1.cola.isEmpty() && !j2.cola.isEmpty() && !j3.cola.isEmpty() && !j4.cola.isEmpty())
		{
			if (j1.cola.peek().valor==6 || (!mesa.mesa.isEmpty() && (j1.cola.peek().valor==mesa.mesa.peek().valor+1 || j1.cola.peek().valor==mesa.mesa.peek().valor-1) && j1.cola.peek().palo==mesa.mesa.peek().palo))
			{
				Carta c = j1.cola.remove();
				mesa.mesa.push(c);
			}
			else
			{
				Carta c = j1.cola.remove();
				j1.cola.add(c);
			}
			
			if (j2.cola.peek().valor==6 || (!mesa.mesa.isEmpty() && (j2.cola.peek().valor==mesa.mesa.peek().valor+1 || j2.cola.peek().valor==mesa.mesa.peek().valor-1) && j2.cola.peek().palo==mesa.mesa.peek().palo))
			{
				Carta c = j2.cola.remove();
				mesa.mesa.push(c);
			}
			else
			{
				Carta c = j2.cola.remove();
				j2.cola.add(c);	
			}
			
			
			if (j3.cola.peek().valor==6 || (!mesa.mesa.isEmpty() && (j3.cola.peek().valor==mesa.mesa.peek().valor+1 || j3.cola.peek().valor==mesa.mesa.peek().valor-1) && j3.cola.peek().palo==mesa.mesa.peek().palo))
			{
				Carta c = j3.cola.remove();
				mesa.mesa.push(c);
			}
			else
			{
				Carta c = j3.cola.remove();
				j3.cola.add(c);
			}
			
			
			if (j4.cola.peek().valor==6 || (!mesa.mesa.isEmpty() && (j4.cola.peek().valor==mesa.mesa.peek().valor+1 || j4.cola.peek().valor==mesa.mesa.peek().valor-1) && j4.cola.peek().palo==mesa.mesa.peek().palo))
			{
				Carta c = j4.cola.remove();
				mesa.mesa.push(c);
			}
			else
			{
				Carta c = j4.cola.remove();
				j4.cola.add(c);
			}
		}
		
		
		if (j1.cola.isEmpty())
		{
			System.out.println("j1 ha ganado");
		}
		else if(j2.cola.isEmpty())
		{
			System.out.println("j2 ha ganado");
		}
		else if(j3.cola.isEmpty())
		{
			System.out.println("j3 ha ganado");	
		}
		else if(j4.cola.isEmpty())
		{
			System.out.println("j4 ha ganado");
		}
	}
	
	
}
