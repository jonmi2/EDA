package poker;

import java.util.ArrayList;
import java.util.Stack;

public class Juego 
{
	
	public Juego()
	{
		
	}
	
	public int Jugar(int nJugadores, int nBilletesInicial, ArrayList<Pago> pagos)
	{
		//pre: 2<=nJugadores<=20, nBilletesInicial>=1, todos los pagos son correctos (todo jugador tiene los billetes necesarios para pagar al otro)
		//post: el rdo es el num de billetes verdaderos del del jugador 0
		int rdo = 0;
		
		Stack<Boolean>[] jugadores = new Stack[nJugadores];
		
		for (int i=0; i<nJugadores; i++)
		{
			jugadores[i] = new Stack<Boolean>();
			
			for (int j=1; j<nBilletesInicial; j++)
			{
				if (i==0)
				{
					jugadores[i].push(false);
				}
				else
				{
					jugadores[i].push(true);
				}
			}
			
		}
		
		for (Pago p: pagos)
		{
			for(int k=0; k<p.cantidad; k++)
			{
				boolean b = jugadores[p.pagador].pop();
				jugadores[p.cobrador].push(b);
			}
		}
		
		while (!jugadores[0].isEmpty())
		{
			boolean a = jugadores[0].pop();
			if(a==true)
			{
				rdo++;
			}
		}
		
		return rdo;
	}
}
