package poker;

import java.util.ArrayList;

public class Main 
{
	public static void main(String[] args)
	{
		Juego j = new Juego();
		ArrayList<Pago> pagos = new ArrayList<Pago>(); 
		Pago p1 = new Pago(0,1,3);
		Pago p2 = new Pago(1,2,2);
		Pago p3 = new Pago(2,0,5);
		Pago p4 = new Pago(1,0,2);
		Pago p5 = new Pago(2,0,1);
		pagos.add(p1);
		pagos.add(p2);
		pagos.add(p3);
		pagos.add(p4);
		pagos.add(p5);
		
		System.out.println("tiene que dar 5 y da....    ");
		System.out.println(j.Jugar(3, 5, pagos));
	}
}
