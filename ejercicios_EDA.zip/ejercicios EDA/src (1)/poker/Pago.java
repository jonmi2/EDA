package poker;

public class Pago 
{
	
	public Pago(int pag, int cob, int canti)
	{
		this.pagador=pag;
		this.cantidad=canti;
		this.cobrador=cob;
	}
	
	public int pagador;
	public int cobrador;
	public int cantidad;
}
