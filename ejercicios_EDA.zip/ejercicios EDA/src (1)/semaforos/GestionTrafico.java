package semaforos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class GestionTrafico 
{
	int NSEMAFOROS = 20;
	int N = 5; // n�mero m�ximo de coches que pasan cuando el sem�foro se pone en verde
	int SALIDA = 99999; // valor especial para salir de la ciudad
	
	public GestionTrafico() {}
	
	public Integer aDonde(String matricula)
	{
		// Post: el resultado es un valor que indica el sem�foro en el que se
		//colocar� ese veh�culo cuando sale del sem�foro (puede ser la SALIDA)
		Random random = new Random();
        // Generar un n�mero aleatorio en el rango de 0 a 19
        int numeroAleatorio = random.nextInt(20);
        // Devolver el n�mero aleatorio generado
        return numeroAleatorio;
	}
	 
	 
	public void simularTrafico(ArrayList<Evento> eventos)
	{
		// Post: se han realizado los movimientos correspondientes a �eventos�. Se han escrito
		//en la salida los movimientos realizados para saber en qu� sem�foro se encuentra un coche

		
		
		// Inicializar sem�foros y cocheSemaforo
		HashMap<String, Integer> cocheSemaforo = new HashMap<String, Integer>();
		
		Queue<String>[] semaforos = new Queue[20];
		for (int i=0; i<=19; i++){semaforos[i]=new LinkedList<String>();}

		 // ���Completar el c�digo!!!
	}
		
	
	 
}

