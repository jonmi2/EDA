package semaforos;

public class Main 
{
	public static void main(String[] args)
	{
		GestionTrafico gs = new GestionTrafico();
		
		
		System.out.println(gs.aDonde("aaa"));
		System.out.println(gs.aDonde("aaa"));
		System.out.println(gs.aDonde("aaa"));		
		System.out.println(gs.aDonde("aaa"));
		System.out.println(gs.aDonde("aaa"));
		System.out.println(gs.aDonde("aaa"));
		System.out.println(gs.aDonde("aaa"));

	}
}
