package colegas;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Grafo 
{
	boolean[][] adjMatrix;
	String[] vertices;
	int numVertices;
	
	public Grafo(int i)
	{
		this.adjMatrix=new boolean[i][i];
		this.vertices=new String[i];
		this.numVertices=i;
	}
	
	/*public int index(String t)
	{
		//pre: t est� en el grafo
		//post: devuelve el indice de t en el array "vertices"
		int indice=0;
		boolean enc = false;
		while(!enc)
		{
			if (this.vertices[indice].equals(t))
			{
				enc=true;
			}
			else
			{
				indice++;
			}
		}		
		return indice;
	}*/
	
	public int index(String t) {
	    // pre: t est� en el grafo
	    // post: devuelve el indice de t en el array "vertices"
	    for (int indice = 0; indice < numVertices; indice++) {
	        if (this.vertices[indice].equals(t)) {
	            return indice;
	        }
	    }
	    return -1; // Si no se encuentra, devolver -1
	}
	
	public ArrayList<String> calcularColegasActivos(String socio, ArrayList<String> inactivos)
	{
		ArrayList<String> rdo = new ArrayList<String>();
		LinkedList<Integer> porEx = new LinkedList<Integer>();
		boolean[] examinados = new boolean[numVertices];
		rdo.add(socio);
		examinados[this.index(socio)]=true;
		for (int i=0; i<numVertices; i++)
		{
			if (this.adjMatrix[this.index(socio)][i]==true && !inactivos.contains(vertices[i]))
			{
				porEx.add(i);
				rdo.add(vertices[i]);
				examinados[i] = true;//nuevo
			}
		}

		while (!porEx.isEmpty())
		{
			int i = porEx.remove();
			for (int j=0; j<numVertices; j++)
			{
				if (this.adjMatrix[i][j]==true && !inactivos.contains(vertices[j]) && !examinados[j])
				{
					porEx.add(j);
					rdo.add(vertices[j]);
				    examinados[j] = true;//nuevo
				}
			}
		}		
		return rdo;		
	}
}