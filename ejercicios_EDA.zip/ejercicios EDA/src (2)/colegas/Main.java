package colegas;

import java.util.ArrayList;
import java.util.Iterator;

public class Main 
{
	public static void main(String[] args)
	{
		Grafo g = new Grafo(10);
		
		
		g.adjMatrix[0][1]=true;
		g.adjMatrix[0][5]=true;
		g.adjMatrix[1][0]=true;
		g.adjMatrix[1][2]=true;
		g.adjMatrix[1][3]=true;
		g.adjMatrix[2][1]=true;
		g.adjMatrix[2][4]=true;
		g.adjMatrix[2][9]=true;
		g.adjMatrix[3][1]=true;
		g.adjMatrix[3][4]=true;
		g.adjMatrix[4][2]=true;
		g.adjMatrix[4][3]=true;
		g.adjMatrix[4][5]=true;
		g.adjMatrix[4][6]=true;
		g.adjMatrix[5][0]=true;
		g.adjMatrix[5][4]=true;
		g.adjMatrix[5][7]=true;
		g.adjMatrix[6][4]=true;
		g.adjMatrix[6][8]=true;
		g.adjMatrix[7][5]=true;
		g.adjMatrix[7][8]=true;
		g.adjMatrix[8][6]=true;
		g.adjMatrix[8][7]=true;
		g.adjMatrix[8][9]=true;
		g.adjMatrix[9][2]=true;
		g.adjMatrix[9][8]=true;
		
		g.vertices[0]="ana";
		g.vertices[1]="jon";
		g.vertices[2]="ida";
		g.vertices[3]="isa";
		g.vertices[4]="pepe";
		g.vertices[5]="luis";
		g.vertices[6]="eki";
		g.vertices[7]="paz";
		g.vertices[8]="ari";
		g.vertices[9]="esti";
		
		ArrayList<String> inactivos = new ArrayList<String>();
		inactivos.add("luis");
		inactivos.add("ida");
		inactivos.add("eki");
		
		ArrayList<String> rdo1 = g.calcularColegasActivos("paz", inactivos);
		Iterator<String> it1 = rdo1.iterator();
		while(it1.hasNext())
		{
			String a = it1.next();
			System.out.println(a);
		}
		
		
		System.out.println("---------------------------------------------------------");
		ArrayList<String> rdo2 = g.calcularColegasActivos("ana", inactivos);
		Iterator<String> it2 = rdo2.iterator();
		while(it2.hasNext())
		{
			String a = it2.next();
			System.out.println(a);
		}
	}
}
