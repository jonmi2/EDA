package colegas2;

import java.util.ArrayList;
import java.util.LinkedList;

public class Grafo 
{
	boolean[][] adjMatrix;
	String[] vertices;
	int numVertices;
	
	public Grafo(int i)
	{
		this.adjMatrix=new boolean[i][i];
		this.vertices=new String[i];
		this.numVertices=i;
	}
	
	public int index(String t) {
	    // pre: t est� en el grafo
	    // post: devuelve el indice de t en el array "vertices"
	    for (int indice = 0; indice < numVertices; indice++) {
	        if (this.vertices[indice].equals(t)) {
	            return indice;
	        }
	    }
	    return -1; // Si no se encuentra, devolver -1
	}
	
	public ArrayList<String> calcularColegasActivos(String socio, ArrayList<String> inactivos)
	{
		ArrayList<String> rdo = new ArrayList<String>();
		rdo.add(socio);
		LinkedList<String> porEx = new LinkedList<String>();
		boolean[] examinados = new boolean[this.numVertices];
		porEx.add(socio);
		examinados[this.index(socio)]=true;
		
		while (!porEx.isEmpty())
		{
			String s = porEx.remove();
			for (int i=0; i<this.numVertices; i++)
			{					
				if (this.adjMatrix[this.index(s)][i] && !examinados[i] && !inactivos.contains(this.vertices[i]))
				{
					porEx.add(this.vertices[i]);
					examinados[i]=true;
					rdo.add(this.vertices[i]);
				}
			}
		}
		
		return rdo;
	}
}
