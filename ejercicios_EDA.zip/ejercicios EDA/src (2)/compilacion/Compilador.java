package compilacion;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

public class Compilador 
{
	HashMap<String, ArrayList<String>> dependencias;
	
	public Compilador() {this.dependencias=new HashMap<String, ArrayList<String>>();}
	
	public boolean esValido(String prog)
	{
		if (!this.dependencias.containsKey(prog))
		{
			return false;
		}
		else
		{
			boolean es=true;
			LinkedList<String> porEx = new LinkedList<String>();
			LinkedList<String> examinados = new LinkedList<String>();
			porEx.add(prog);
			examinados.add(prog);
			while (es && !porEx.isEmpty())
			{
				String p = porEx.remove();
				if (!this.dependencias.containsKey(p))
				{
					return false;
				}
				else
				{
					Iterator<String> itr = this.dependencias.get(p).iterator();
					while (itr.hasNext())
					{
						String pr = itr.next();
						if (!this.dependencias.containsKey(prog)) 
						{
							return false;
						}
						else
						{
							if (!examinados.contains(pr)) 
							{
								porEx.add(pr);
								examinados.add(pr);
							}
						}
					}
				}
			}			
			return es;
		}
	}
}
