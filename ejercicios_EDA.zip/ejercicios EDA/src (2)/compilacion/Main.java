package compilacion;

import java.util.ArrayList;

public class Main 
{
	public static void main(String[] args)
	{
		Compilador cp = new Compilador();
		
		ArrayList<String> a1= new ArrayList<String>();
		a1.add("PR2");
		a1.add("PR3");
		
		ArrayList<String> a2= new ArrayList<String>();
		a2.add("PR5");
		a2.add("PR3");
		
		ArrayList<String> a3= new ArrayList<String>();
		a3.add("PR5");
		a3.add("PR14");
		
		ArrayList<String> a4= new ArrayList<String>();
		a4.add("PR5");
		
		ArrayList<String> a5= new ArrayList<String>();
		a5.add("PR2");
		
		ArrayList<String> a6= new ArrayList<String>();
		a6.add("PR25");
		
		cp.dependencias.put("PR1", a1);
		cp.dependencias.put("PR2", a2);
		cp.dependencias.put("PR15", a3);
		cp.dependencias.put("PR3", a4);
		cp.dependencias.put("PR5", a5);
		cp.dependencias.put("PR14", a6);
		
		System.out.println(cp.esValido("PR1"));//TRUE
		System.out.println(cp.esValido("PR25"));//FALSE
		System.out.println(cp.esValido("PR112"));//FALSE
		System.out.println(cp.esValido("PR15"));//FALSE
		System.out.println(cp.esValido("PR5"));//TRUE
	}
}
