package contactomasayuda;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Contactos 
{
	boolean[][] adjMatrix;
	
	public Contactos(int tama�o)
	{
		this.adjMatrix = new boolean[tama�o][tama�o];
	}
	
	public boolean sonCompatibles(Integer p1, Integer p2)
	{
		if ((p1==4 && p2==7) || (p1==7 && p2==4))
		{
			return true;
		}
		else if ((p1==4 && p2==10) || (p1==10 && p2==4))
		{
			return true;
		}
		else if ((p1==2 && p2==10) || (p1==10 && p2==2))
		{
			return true;
		}
		else if ((p1==8 && p2==7) || (p1==7 && p2==8))
		{
			return true;
		}
		else if ((p1==8 && p2==10) || (p1==10 && p2==8))
		{
			return true;
		}
		else if ((p1==9 && p2==7) || (p1==7 && p2==9))
		{
			return true;
		}		
		else
		{
			return false;
		}
	}
	
	public int elqmaspuedeayudar(ArrayList<Integer> personas)
	{
		int[] ayudas = new int[this.adjMatrix.length];//se inicializan todas a 0
		Iterator<Integer> itr = personas.iterator();
		while (itr.hasNext())
		{
			int i = itr.next();
			LinkedList<Integer> porEx = new LinkedList<Integer>();
			porEx.add(i);
			boolean[] examinados = new boolean[this.adjMatrix.length];
			while(!porEx.isEmpty())
			{
				int ex = porEx.remove();
				for (int k=0; k<this.adjMatrix.length; k++)
				{
					if (this.adjMatrix[ex][k] && !examinados[k])
					{
						examinados[k]=true;
						porEx.add(k);					
						if (this.sonCompatibles(ex, k)) {ayudas[k] = ayudas[k]+1;}
					}
				}
			}			
		}
		
		int max=0;
		int cont=0;
		for (int k=0; k<this.adjMatrix.length; k++)
		{
			if (ayudas[k]>cont) 
			{
				cont=ayudas[k];
				max=k;
			}
		}
		
		return max;
	}
}
