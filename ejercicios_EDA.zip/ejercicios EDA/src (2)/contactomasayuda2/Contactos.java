package contactomasayuda2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class Contactos 
{
	boolean[][] adjMatrix;
	
	public Contactos(int tama�o)
	{
		this.adjMatrix = new boolean[tama�o][tama�o];
	}
	
	public boolean sonCompatibles(Integer p1, Integer p2)
	{
		if ((p1==4 && p2==7) || (p1==7 && p2==4))
		{
			return true;
		}
		else if ((p1==4 && p2==10) || (p1==10 && p2==4))
		{
			return true;
		}
		else if ((p1==2 && p2==10) || (p1==10 && p2==2))
		{
			return true;
		}
		else if ((p1==8 && p2==7) || (p1==7 && p2==8))
		{
			return true;
		}
		else if ((p1==8 && p2==10) || (p1==10 && p2==8))
		{
			return true;
		}
		else if ((p1==9 && p2==7) || (p1==7 && p2==9))
		{
			return true;
		}		
		else
		{
			return false;
		}
	}
	
	public int elqmaspuedeayudar(ArrayList<Integer> personas)
	{
		Iterator<Integer> itr = personas.iterator();
		int[] ayudantes = new int[this.adjMatrix.length];
		while (itr.hasNext())
		{
			Integer p = itr.next();
			LinkedList<Integer> porEx = new LinkedList<Integer>();
			boolean[] examinados = new boolean[this.adjMatrix.length];
			porEx.add(p);
			examinados[p]=true;
			while(!porEx.isEmpty())
			{
				int k = porEx.remove();
				for (int i=0; i<this.adjMatrix.length; i++)
				{
					if (this.adjMatrix[k][i] && !examinados[i])
					{
						porEx.add(i);
						examinados[i]=true;
						if (this.sonCompatibles(p, i)) {ayudantes[i]++;}
					}
				}
			}
			
		}
		
		int rdo=0;
		int cont=0;
		for (int j=0; j<this.adjMatrix.length; j++)
		{			
			if (ayudantes[j]>cont)
			{
				rdo=j;
				cont=ayudantes[j];
			}		
		}	
		return rdo;
	}
}
