package contactomasayuda2;

import java.util.ArrayList;


public class Main 
{
	public static void main(String[] args)
	{
		Contactos c = new Contactos(16);
		c.adjMatrix[0][7]=true;
		c.adjMatrix[0][2]=true;
		c.adjMatrix[1][15]=true;
		c.adjMatrix[2][5]=true;
		c.adjMatrix[2][6]=true;
		c.adjMatrix[3][15]=true;
		c.adjMatrix[4][0]=true;
		c.adjMatrix[5][10]=true;
		c.adjMatrix[8][1]=true;
		c.adjMatrix[8][7]=true;
		c.adjMatrix[9][14]=true;
		c.adjMatrix[9][13]=true;
		c.adjMatrix[9][12]=true;
		c.adjMatrix[10][11]=true;
		c.adjMatrix[11][7]=true;
		c.adjMatrix[12][7]=true;
		c.adjMatrix[12][13]=true;
		
		ArrayList<Integer> personas = new ArrayList<Integer>();
		personas.add(4);
		personas.add(8);
		personas.add(2);
		personas.add(9);
		int rdo = c.elqmaspuedeayudar(personas);
		System.out.println(rdo);
	}
}
