package herencia;

import java.util.LinkedList;
import java.util.Queue;

public class GraphAL
{
	protected final int capacity=100;
	protected int numVertices;
	protected LinkedList<Integer>[] adjList;
	protected String[] vertices;
	
	public GraphAL(int personas)
	{
		this.numVertices=personas;
		this.adjList =new LinkedList[personas];
		for (int i=0; i<personas; i++)
		{
			this.adjList[i]=new LinkedList<Integer>();
		}
		this.vertices=new String[personas];
	}
	
	public int index(String t)
	{
		//pre: t est� en el grafo
		//post: devuelve el indice de t en el array "vertices"
		int indice=0;
		boolean enc = false;
		while(!enc)
		{
			if (this.vertices[indice].equals(t))
			{
				enc=true;
			}
			else
			{
				indice++;
			}
		}		
		return indice;
	}

	public int repartir(int cantidad, int n, String persona) 
	{
	    int rdo = 0;
	    int recibidores = 0;
	    int niveles = n;
	    Queue<Integer> porEx = new LinkedList<Integer>();
	    boolean[] examinados = new boolean[this.numVertices];
	    porEx.add(this.index(persona));
	    examinados[this.index(persona)] = true;

	    while (!porEx.isEmpty() && niveles > 0) 
	    {
	        int size = porEx.size();
	        for (int i = 0; i < size; i++) 
	        {
	            int p = porEx.remove();
	            int sizeAdjList = adjList[p].size();
	            for (int j = 0; j < sizeAdjList; j++) 
	            {
	                int h = adjList[p].get(j);
	                if (!examinados[h]) 
	                {
	                    recibidores++;
	                    examinados[h] = true;
	                    porEx.add(h);
	                }
	            }
	        }
	        niveles--;
	    }
	    rdo = cantidad / recibidores;
	    return rdo;
	}

}
