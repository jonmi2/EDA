package herencia2;

import java.util.LinkedList;
import java.util.Queue;

public class GraphAL 
{
	protected final int capacity=100;
	protected int numVertices;
	protected LinkedList<Integer>[] adjList;
	protected String[] vertices;
	
	public GraphAL(int personas)
	{
		this.numVertices=personas;
		this.adjList =new LinkedList[personas];
		for (int i=0; i<personas; i++)
		{
			this.adjList[i]=new LinkedList<Integer>();
		}
		this.vertices=new String[personas];
	}
	
	public int getIndice (String p)
	{
		int indice=0;
		boolean enc = false;
		while(!enc)
		{
			if (this.vertices[indice].equals(p))
			{
				enc=true;
			}
			else
			{
				indice++;
			}
		}		
		return indice;
	}
	
	public int repartir(int cantidad, int n, String p)
	{
		if (n==0)
		{
			return 0;
		}
		else
		{
			boolean[] examinados = new boolean[this.numVertices]; 
			LinkedList<String> porEx = new LinkedList<String>();
			LinkedList<String> recibidores = new LinkedList<String>();
			int niveles=n;
			
			porEx.add(p);
			examinados[this.getIndice(p)]=true;
			
			while (!porEx.isEmpty() && niveles>0)
			{
				int vuelta = porEx.size();
				for (int k=0; k<vuelta; k++)
				{
					String persona = porEx.remove();
					int size = this.adjList[this.getIndice(persona)].size();
					for (int i=0; i<size; i++)
					{
						int heredero = this.adjList[this.getIndice(persona)].remove();
						if (!examinados[heredero])
						{
							porEx.add(this.vertices[heredero]);
							examinados[heredero]=true;
							recibidores.add(this.vertices[heredero]);
						}
						this.adjList[this.getIndice(persona)].add(heredero);
					}
				}
				niveles=niveles-1;
			}			
			return cantidad/recibidores.size();
		}
	}
}


