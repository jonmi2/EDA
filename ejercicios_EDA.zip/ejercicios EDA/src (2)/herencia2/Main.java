package herencia2;


public class Main 
{
	public static void main(String[] args)
	{
		GraphAL g = new GraphAL(21);
		
		g.vertices[0]="pedro";
		g.vertices[1]="jon";
		g.vertices[2]="amaia";
		g.vertices[3]="xabi";
		g.vertices[4]="iker";
		g.vertices[5]="markel";
		g.vertices[6]="gorka";
		g.vertices[7]="santi";
		g.vertices[8]="bego";
		g.vertices[9]="kepa";
		g.vertices[10]="sara";
		g.vertices[11]="juan";
		g.vertices[12]="ana";
		g.vertices[13]="ander";
		g.vertices[14]="pilar";
		g.vertices[15]="luisa";
		g.vertices[16]="joseba";
		g.vertices[17]="aurora";
		g.vertices[18]="luis";
		g.vertices[19]="oscar";
		g.vertices[20]="gorka";
		
		g.adjList[0].add(1);
		g.adjList[0].add(2);
		g.adjList[0].add(3);
		g.adjList[0].add(4);
		g.adjList[1].add(0);
		g.adjList[2].add(0);
		g.adjList[2].add(3);
		g.adjList[2].add(5);
		g.adjList[3].add(0);
		g.adjList[3].add(2);
		g.adjList[3].add(4);
		g.adjList[3].add(6);
		g.adjList[3].add(7);
		g.adjList[4].add(0);
		g.adjList[4].add(3);
		g.adjList[4].add(9);
		g.adjList[4].add(8);
		g.adjList[5].add(2);
		g.adjList[5].add(20);
		g.adjList[6].add(3);
		g.adjList[6].add(16);
		g.adjList[7].add(3);
		g.adjList[7].add(14);
		g.adjList[8].add(4);
		g.adjList[9].add(4);
		g.adjList[9].add(10);
		g.adjList[9].add(11);
		g.adjList[10].add(9);
		g.adjList[11].add(9);
		g.adjList[11].add(12);
		g.adjList[11].add(13);
		g.adjList[12].add(11);
		g.adjList[12].add(13);
		g.adjList[13].add(11);
		g.adjList[13].add(12);
		g.adjList[14].add(7);
		g.adjList[15].add(16);
		g.adjList[16].add(6);
		g.adjList[16].add(15);
		g.adjList[16].add(17);
		g.adjList[17].add(16);
		g.adjList[18].add(19);
		g.adjList[18].add(20);
		g.adjList[19].add(18);
		g.adjList[20].add(5);
		g.adjList[20].add(18);
		
		System.out.println(g.repartir(100000, 2, "pedro"));
	}
}
