package juego;

public class Casilla 
{
	String color;
	Integer valor;
	
	public Casilla(String c, Integer v)
	{
		this.color=c;
		this.valor=v;
	}
	
	public boolean equals(Casilla c)
	{
		boolean eq = false;
		if (c.color==this.color && c.valor==this.valor)
		{
			eq=true;
		}
		return eq;
	}
}
