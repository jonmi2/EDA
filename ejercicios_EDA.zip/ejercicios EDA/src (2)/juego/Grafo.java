package juego;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class Grafo 
{
	 HashMap<Integer, ArrayList<Casilla>> adjs;//key=num de casilla || valor=lista de casillas adyacentes
	 
	 
	 public Grafo()
	 {
		 SIN TERMINAAAAAAAAAAAAAAAAAAAAAAAAAAAAAR
		   Casilla c11 = new Casilla("blanco", 11);
		   Casilla c5  = new Casilla("blanco", 5);
		   Casilla c13 = new Casilla("negro", 13);
		   Casilla c8  = new Casilla("blanco", 8);
		   Casilla c9  = new Casilla("negro", 9);
		   Casilla c1  = new Casilla("blanco", 1);
		   Casilla c3  = new Casilla("negro", 3);
		   Casilla c7  = new Casilla("negro", 7);
		   Casilla c12 = new Casilla("negro", 12);
		   Casilla c4  = new Casilla("blanco", 4);
		   Casilla c17 = new Casilla("negro", 17);
		   Casilla c20 = new Casilla("blanco", 20);

		   ArrayList<Casilla> lista11 = new ArrayList<Casilla>();
		   lista11.add(c5);
		   lista11.add(c13);
		   
		   ArrayList<Casilla> lista5 = new ArrayList<Casilla>();
		   lista5.add(c8);
		   lista5.add(c9);
		   lista5.add(c11);
		   lista5.add(c13);
		   
		   ArrayList<Casilla> lista13 = new ArrayList<Casilla>();
		   lista13.add(c5);
		   lista13.add(c8);
		   lista13.add(c11);
		   
		   ArrayList<Casilla> lista8 = new ArrayList<Casilla>();
		   lista8.add(c5);
		   lista8.add(c9);
		   lista8.add(c13);
		   
		   ArrayList<Casilla> lista9 = new ArrayList<Casilla>();
		   lista9.add(c1);
		   lista9.add(c3);
		   lista9.add(c5);
		   lista9.add(c7);
		   lista9.add(c8);
		   lista9.add(c12);
		   
		   ArrayList<Casilla> lista1 = new ArrayList<Casilla>();
		   lista1.add(c3);
		   lista1.add(c4);
		   lista1.add(c9);
		   lista1.add(c17);
		   
		   ArrayList<Casilla> lista3 = new ArrayList<Casilla>();
		   lista3.add(c1);
		   lista3.add(c4);
		   lista3.add(c9);
		   lista3.add(c12);
		   lista3.add(c17);
		   
		   ArrayList<Casilla> lista7 = new ArrayList<Casilla>();
		   lista7.add(c9);
		   lista7.add(c12);
		   
		   ArrayList<Casilla> lista12 = new ArrayList<Casilla>();
		   lista12.add(c3);
		   lista12.add(c7);
		   lista12.add(c9);
		   lista12.add(c17);
		   lista12.add(c20);
		   
		   ArrayList<Casilla> lista4 = new ArrayList<Casilla>();
		   lista4.add(c1);
		   lista4.add(c3);
		   lista4.add(c17);
		   lista4.add(c20);
		   
		   ArrayList<Casilla> lista17 = new ArrayList<Casilla>();
		   lista17.add(c1);
		   lista17.add(c3);
		   lista17.add(c4);
		   lista17.add(c12);
		   lista17.add(c20);
		   
		   ArrayList<Casilla> lista20 = new ArrayList<Casilla>();
		   lista20.add(c4);
		   lista20.add(c12);
		   lista20.add(c17);

		   this.adjs = new HashMap<Integer, ArrayList<Casilla>>();
		   this.adjs.put(11, lista11);
		   this.adjs.put(5, lista5);
		   this.adjs.put(13, lista13);
		   this.adjs.put(8, lista8);
		   this.adjs.put(9, lista9);
		   this.adjs.put(1, lista1);
		   this.adjs.put(3, lista3);
		   this.adjs.put(7, lista7);
		   this.adjs.put(12, lista12);
		   this.adjs.put(4, lista4);
		   this.adjs.put(17, lista17);
		   this.adjs.put(20, lista20);
	 }
	 
	 public LinkedList<Casilla> camino(Casilla c, Casilla f)
	 {
		 LinkedList<Casilla> rdo = new LinkedList<Casilla>();		 
		 LinkedList<Casilla> porEx = new LinkedList<Casilla>();
		 LinkedList<Casilla> examinados = new LinkedList<Casilla>();
		 porEx.add(c);
		 examinados.add(c);
		 
		 for (int i=0; i<adjs.get(c.valor).size(); i++)
		 {
			 if (adjs.get(c.valor).get(i).color!=c.color && !examinados.contains(adjs.get(c.valor).get(i)))
			 {
				 porEx.add(adjs.get(c.valor).get(i));
				 //examinados.add(adjs.get(c.valor).get(i));
			 }
		 }
		 
		 while (!porEx.isEmpty())
		 {
			 Casilla ca = porEx.remove();
			 rdo.add(ca);
			 if(!examinados.contains(ca))
			 {
				 examinados.add(ca);
				 for (int i=0; i<adjs.get(ca.valor).size(); i++)
				 {
					 if (adjs.get(ca.valor).get(i).color!=c.color && !examinados.contains(adjs.get(ca.valor).get(i)))
					 {
						 porEx.add(adjs.get(ca.valor).get(i));
						 examinados.add(adjs.get(ca.valor).get(i));						 
					 }
				 }
			 }
		 }		 
		 return rdo;
	 }
	 
}
