package juego;

import java.util.ArrayList;
import java.util.LinkedList;

public class Main 
{
	public static void main(String[] args)
	{
		Grafo g = new Grafo();
		Casilla c11 = new Casilla("blanco", 11);
		Casilla c20 = new Casilla("blanco", 20);
		LinkedList<Casilla> rdo = g.camino(c11, c20);
		while (!rdo.isEmpty())
		{
			Casilla c = rdo.remove();
			System.out.println(c.color +"<->"+ c.valor);
		}
	}
}
