package juego2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;


public class Grafo 
{
	HashMap<Integer, ArrayList<Casilla>> adjs;//key=num de casilla || valor=lista de casillas adyacentes
	 
	 
	 public Grafo()
	 {
		   Casilla c0 = new Casilla("blanco", 0);
		   Casilla c1  = new Casilla("blanco", 1);
		   Casilla c2 = new Casilla("negro", 2);
		   Casilla c3  = new Casilla("blanco", 3);
		   Casilla c4  = new Casilla("negro", 4);
		   Casilla c8  = new Casilla("blanco", 8);
		   Casilla c7  = new Casilla("negro", 7);
		   Casilla c5  = new Casilla("negro", 5);
		   Casilla c6 = new Casilla("negro", 6);
		   Casilla c9  = new Casilla("blanco", 9);
		   Casilla c10 = new Casilla("negro", 10);
		   Casilla c11 = new Casilla("blanco", 11);

		   ArrayList<Casilla> lista0 = new ArrayList<Casilla>();
		   lista0.add(c1);
		   lista0.add(c2);
		   
		   ArrayList<Casilla> lista1 = new ArrayList<Casilla>();
		   lista1.add(c0);
		   lista1.add(c2);
		   lista1.add(c3);
		   lista1.add(c4);
		   
		   ArrayList<Casilla> lista2 = new ArrayList<Casilla>();
		   lista2.add(c0);
		   lista2.add(c1);
		   lista2.add(c3);
		   
		   ArrayList<Casilla> lista3 = new ArrayList<Casilla>();
		   lista3.add(c1);
		   lista3.add(c2);
		   lista3.add(c4);
		   
		   ArrayList<Casilla> lista4 = new ArrayList<Casilla>();
		   lista4.add(c1);
		   lista4.add(c3);
		   lista4.add(c5);
		   lista4.add(c7);
		   lista4.add(c8);
		   lista4.add(c6);
		   
		   ArrayList<Casilla> lista5 = new ArrayList<Casilla>();
		   lista5.add(c4);
		   lista5.add(c6);
		   
		   ArrayList<Casilla> lista6 = new ArrayList<Casilla>();
		   lista6.add(c5);
		   lista6.add(c4);
		   lista6.add(c7);
		   lista6.add(c10);
		   lista6.add(c11);
		   
		   ArrayList<Casilla> lista7 = new ArrayList<Casilla>();
		   lista7.add(c4);
		   lista7.add(c6);
		   lista7.add(c8);
		   lista7.add(c10);
		   lista7.add(c9);
		   
		   ArrayList<Casilla> lista8 = new ArrayList<Casilla>();
		   lista8.add(c4);
		   lista8.add(c7);
		   lista8.add(c9);
		   lista8.add(c10);
		   
		   ArrayList<Casilla> lista9 = new ArrayList<Casilla>();
		   lista4.add(c7);
		   lista4.add(c8);
		   lista4.add(c10);
		   lista4.add(c11);
		   
		   ArrayList<Casilla> lista10 = new ArrayList<Casilla>();
		   lista10.add(c6);
		   lista10.add(c7);
		   lista10.add(c8);
		   lista10.add(c9);
		   lista10.add(c11);
		   
		   ArrayList<Casilla> lista11 = new ArrayList<Casilla>();
		   lista11.add(c9);
		   lista11.add(c10);
		   lista11.add(c6);

		   this.adjs = new HashMap<Integer, ArrayList<Casilla>>();
		   this.adjs.put(0, lista0);
		   this.adjs.put(1, lista1);
		   this.adjs.put(2, lista2);
		   this.adjs.put(3, lista3);
		   this.adjs.put(4, lista4);
		   this.adjs.put(8, lista5);
		   this.adjs.put(7, lista6);
		   this.adjs.put(5, lista7);
		   this.adjs.put(6, lista8);
		   this.adjs.put(9, lista9);
		   this.adjs.put(10, lista10);
		   this.adjs.put(11, lista11);
	 }
	 
	 public LinkedList<Casilla> camino(Casilla c, Casilla f)
	 {
		 /*boolean[] examinados = new boolean[this.adjs.size()];
		 LinkedList<Casilla> porEx = new LinkedList<Casilla>();
		 LinkedList<Casilla> rdo = new LinkedList<Casilla>();
		 examinados[c.valor]=true;
		 porEx.add(c);
		 rdo.add(c);
		 boolean enc=false;
		 
		 while (!porEx.isEmpty() && !enc)
		 {
			 Casilla k=porEx.remove();
			 ArrayList<Casilla> adjsk = this.adjs.get(k.valor);
			 if (adjsk.contains(f) && k.color!=f.color)
			 {
				 enc=true;
				 rdo.add(f);
			 }
			 else
			 {
				 Iterator<Casilla> itr = adjsk.iterator();
				 while (itr.hasNext())
				 {
					 Casilla a = itr.next();
					 if (!examinados[a.valor] && a.color!=k.color)
					 {
						 rdo.add(a);
						 porEx.add(a);
						 examinados[a.valor]=true;						
					 }				
				 }
			 }
			 
		 }	 
		 return rdo;*/
		 Queue<Casilla> sinExaminar = new LinkedList<Casilla>();

	      HashSet<Casilla> visitados = new HashSet<Casilla>();
	      HashMap<Casilla, Casilla> camino = new HashMap<Casilla, Casilla>();

	      LinkedList<Casilla> resultado = new LinkedList<Casilla>();


	      sinExaminar.add(c);
	      camino.put(c,  null);
	      visitados.add(c);
	      boolean enc = false;
	      Casilla act = null;;
	      
	      while (!enc && !sinExaminar.isEmpty()) {
	    	  act = sinExaminar.remove();
	    	  // System.out.println(act.toString());
	    	  
	    	  if (act.equals(f)) enc = true;
	    	  else {
	    		  ArrayList<Casilla> contiguas = this.adjs.get(act.valor);
	    	   
	    		  for (Casilla dest: contiguas){
	    			  if (!act.color.equals(dest.color) && !visitados.contains(dest)){
	        			  // System.out.println(dest.toString());
	    				  sinExaminar.add(dest);
	    				  camino.put(dest, act);
	    				  visitados.add(dest);
	    			  }
	    		  }
	    	  }
	      }
	    		  
	      if (enc) {
	    	  while (act != null){
				  System.out.println("RES: " + act.toString());
	    		  resultado.add(act);
	    		  act = camino.get(act);
	    	  }
	      }

	      return resultado;
	 }
}
