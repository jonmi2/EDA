package juego2;

import java.util.LinkedList;


public class Main 
{
	public static void main(String[] args)
	{
		Grafo g = new Grafo();
		Casilla c0 = new Casilla("blanco", 0);
		Casilla c11 = new Casilla("blanco", 11);
		LinkedList<Casilla> rdo = g.camino(c0, c11);
		while (!rdo.isEmpty())
		{
			Casilla c = rdo.remove();
			System.out.println(c.color +"<->"+ c.valor);
		}
	}
}
