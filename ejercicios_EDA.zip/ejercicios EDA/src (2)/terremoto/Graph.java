package terremoto;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Graph 
{
	protected final int CAPACITY=100;
	protected int numVertices;
	protected boolean[][] adjMatrix;
	protected String[] vertices;
	
	
	public Graph(int nV)
	{
		this.numVertices=nV;
		this.adjMatrix=new boolean[nV][nV];
		this.vertices=new String[nV];
	}
	
	public int index(String t)
	{
		//pre: t est� en el grafo
		//post: devuelve el indice de t en el array "vertices"
		int indice=0;
		boolean enc = false;
		while(!enc)
		{
			if (this.vertices[indice].equals(t))
			{
				enc=true;
			}
			else
			{
				indice++;
			}
		}		
		return indice;
	}
	
	public ArrayList<String> afectados (double intensidad, String c)
	{
		
		//pre: c es la comarca
		//post: el rdo es la lista de comarcas afectadas (intensidad=>1)
		//intensidad=intensidad/2 al pasar de una comarca a sus adyacentes
		ArrayList<String> rdo = new ArrayList<String>();
	    double inte = intensidad;
	    Queue<Integer> porEx = new LinkedList<Integer>();
	    boolean[] examinados = new boolean[this.numVertices];// se inicializan todas a false
	    porEx.add(this.index(c));
	    examinados[this.index(c)] = true;

	    while (!porEx.isEmpty() && inte >= 1) 
	    {
	        int size = porEx.size();
	        for (int i = 0; i < size; i++) 
	        {
	            int ciudad = porEx.remove();
	            if (!rdo.contains(this.vertices[ciudad])) {rdo.add(this.vertices[ciudad]);}
	            for (int j = 0; j < this.numVertices; j++)
	            {
	                if (this.adjMatrix[ciudad][j] == true && !examinados[j]) 
	                {
	                    porEx.add(j);
	                    examinados[j] = true;
	                }
	            }
	        }
	        inte = inte / 2;
	    }
	    return rdo;
	}
}
