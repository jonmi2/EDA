package terremoto2;

import java.util.ArrayList;
import java.util.LinkedList;

public class Grafo 
{
	protected final int CAPACITY=100;
	protected int numVertices;
	protected boolean[][] adjMatrix;
	protected String[] vertices;
	
	
	public Grafo(int nV)
	{
		this.numVertices=nV;
		this.adjMatrix=new boolean[nV][nV];
		this.vertices=new String[nV];
	}
	
	public int index(String t)
	{
		//pre: t est� en el grafo
		//post: devuelve el indice de t en el array "vertices"
		int indice=0;
		boolean enc = false;
		while(!enc)
		{
			if (this.vertices[indice].equals(t))
			{
				enc=true;
			}
			else
			{
				indice++;
			}
		}		
		return indice;
	}
	
	public ArrayList<String> afectados (double intensidad, String c)
	{
		double inte=intensidad/2;
		ArrayList<String> rdo = new ArrayList<String>();
		boolean[] examinados = new boolean[this.vertices.length];
		LinkedList<Integer> porEx = new LinkedList<Integer>();
		examinados[this.index(c)]=true;
		porEx.add(this.index(c));
		
		while(!porEx.isEmpty() && inte>=1)
		{
			int porexSize=porEx.size();
			for (int i=0; i<porexSize; i++)
			{
				int ciudad = porEx.remove();
				for (int k=0; k<this.numVertices; k++)
				{
					if (this.adjMatrix[ciudad][k] && !examinados[k])
					{
						porEx.add(k);
						examinados[k]=true;
						rdo.add(this.vertices[k]);
					}
				}
			}
			inte=inte/2;
		}
		
		
		return rdo;
	}
}
