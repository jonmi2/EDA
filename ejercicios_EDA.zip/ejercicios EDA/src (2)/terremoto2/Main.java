package terremoto2;

import java.util.ArrayList;
import java.util.Iterator;

import terremoto.Graph;

public class Main 
{
	public static void main(String[] args)
	{
		Grafo g = new Grafo(12);
		
		g.adjMatrix[0][1]=true;
		g.adjMatrix[0][2]=true;
		g.adjMatrix[0][3]=true;
		g.adjMatrix[1][0]=true;
		g.adjMatrix[1][7]=true;
		g.adjMatrix[1][8]=true;
		g.adjMatrix[2][0]=true;
		g.adjMatrix[2][9]=true;
		g.adjMatrix[2][10]=true;
		g.adjMatrix[2][11]=true;
		g.adjMatrix[3][0]=true;
		g.adjMatrix[3][4]=true;
		g.adjMatrix[3][5]=true;
		g.adjMatrix[3][6]=true;
		g.adjMatrix[4][3]=true;
		g.adjMatrix[5][3]=true;
		g.adjMatrix[6][3]=true;
		g.adjMatrix[7][1]=true;
		g.adjMatrix[7][8]=true;
		g.adjMatrix[8][1]=true;
		g.adjMatrix[8][7]=true;
		g.adjMatrix[9][2]=true;
		g.adjMatrix[10][2]=true;
		g.adjMatrix[10][11]=true;
		g.adjMatrix[11][2]=true;
		g.adjMatrix[11][10]=true;
		
		g.vertices[0]="Bilbao";
		g.vertices[1]="Basa";
		g.vertices[2]="Etxebarri";
		g.vertices[3]="Leioa";
		g.vertices[4]="Gorliz";
		g.vertices[5]="Loiu";
		g.vertices[6]="Sope";
		g.vertices[7]="Arrigo";
		g.vertices[8]="Sanmi";
		g.vertices[9]="Duran";
		g.vertices[10]="Gerni";
		g.vertices[11]="Bolueta";
		
		
		ArrayList<String> rdo = g.afectados(4, "Bilbao");
		Iterator<String> itr = rdo.iterator();
		
		System.out.println("Hay "+rdo.size()+" ciudades afectadas");
		
		while (itr.hasNext())
		{
			String c = itr.next();
			System.out.println(c);
		}
		
	}
	
}
