package arbolesparalelos;

import java.util.ArrayList;

public class ArbolNombres 
{
	public Nodo rootAps;
	public Nodo rootNom;
	
	public ArbolNombres()
	{
		this.rootAps=null;
		this.rootNom=null;
	}
	
	public ArrayList<String> obtenerListaOrdenada()
	{
		//pre: el arbol de apellidos esta ordenado ascendentemente
		ArrayList<String> rdo = new ArrayList<String>();
		this.obtenerListaOrdenada(rootAps, rootNom, rdo);		
		return rdo;		
	}

	private void obtenerListaOrdenada(Nodo aps, Nodo noms, ArrayList<String> rdo) 
	{
		if (aps==null || noms==null)
		{
			
		}
		else //inOrden
		{
			this.obtenerListaOrdenada(aps.left, noms.left, rdo);
			rdo.add(aps.valor+" , "+noms.valor);
			this.obtenerListaOrdenada(aps.right, noms.right, rdo);
		}
	}
}
