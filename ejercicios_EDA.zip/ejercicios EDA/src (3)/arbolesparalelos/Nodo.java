package arbolesparalelos;

public class Nodo 
{
	public String valor;
	public Nodo left;
	public Nodo right;
	
	public Nodo(String v)
	{
		this.valor=v;
		this.right=null;
		this.left=null;	
	}
}
