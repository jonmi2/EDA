package busqueda2;



public class Arbol 
{
	BTN root;
	
	public Arbol()
	{
		this.root=null;
	}
	
	public boolean esta(int elem)
	{
		boolean enc = false;
		return this.esta(elem, this.root, enc);
	}

	private boolean esta(int elem, BTN n, boolean rdo) 
	{
		if(!rdo)
		{
			for (int i=0; i<n.valores.length; i++)
			{
				if (n.valores[i]==elem) {return true;}
			}
			if(n.hijos.length!=0)
			{
				for (int k=0; k<=n.valores.length; k++)
				{
					rdo=this.esta(elem,n.hijos[k],rdo);
				}
			}
		}
		else
		{
			return true;
		}
		return rdo;
	}
	

}
