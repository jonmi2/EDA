package busqueda3;


public class Arbol 
{
	BTN root;
	
	public Arbol()
	{
		this.root=null;
	}
	
	public boolean esta(int elem)
	{
		return this.esta(elem,this.root);
	}

	private boolean esta(int elem, BTN n) 
	{
		boolean enc=false;
		if (n==null)
		{
			return enc;
		}
		else
		{
			for (int i=0; i<n.hijos.length; i++)
			{
				if (n.valores[i]==elem) {return true;}
			}
			if (!enc)
			{
				for (int i=0; i<n.hijos.length; i++)
				{
					return this.esta(elem, n.hijos[i]);
				}
			}
			return enc;
		}
	}
}
