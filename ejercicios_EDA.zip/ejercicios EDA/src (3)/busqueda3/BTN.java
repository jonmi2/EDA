package busqueda3;

public class BTN 
{
	int[] valores;
	BTN[] hijos; //hijos.size = valores.size+1;
	
	public BTN()
	{
		this.hijos=null;
		this.valores=null;
	}
}
