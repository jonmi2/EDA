package busquedaenarbol;

public class Arbol 
{
	BTN root;
	
	public Arbol()
	{
		this.root=null;
	}
	
	public boolean esta(int elem)
	{	
		boolean enc=false;
		return esta(elem,root,enc);
	}

	private boolean esta(int elem, BTN nodo, boolean enc) 
	{
		if (!enc)
		{
			for (int i =0; i<nodo.valores.length; i++)
			{
				if (nodo.valores[i]==elem)
				{
					return true;
				}
			}
			
			if (nodo.hijos.length!=0)
			{
				for (int k = 0; k<nodo.hijos.length; k++)
				{
					enc =  this.esta(elem, nodo.hijos[k], enc);
				}
			}
			return enc;
		}
		else
		{
			return true;
		}
	}
}
