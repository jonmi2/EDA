package busquedaenarbol;

public class Main
{
	public static void main(String[] args)
	{
		BTN n1 = new BTN();
		BTN n2 = new BTN();
		BTN n3 = new BTN();
		BTN n4 = new BTN();
		BTN n5 = new BTN();
		BTN n6 = new BTN();
		BTN n7 = new BTN();
		BTN n8 = new BTN();
		BTN n9 = new BTN();
		BTN n10 = new BTN();
		BTN n11 = new BTN();
		
		int[] n1v = {15,45,75,93};
		BTN[] n1h = {n2,n3,n4,n5,n6};
		n1.hijos=n1h;
		n1.valores=n1v;
		
		int[] n2v = {8};
		BTN[] n2h = {n7,n8};
		n2.hijos=n2h;
		n2.valores=n2v;
		
		int[] n3v = {18,20,30};
		BTN[] n3h = {};
		n3.hijos=n3h;
		n3.valores=n3v;
		
		int[] n4v = {49,52,67,72};
		BTN[] n4h = {};
		n4.hijos=n4h;
		n4.valores=n4v;
		
		int[] n5v = {80,88};
		BTN[] n5h = {n9,n10,n11};
		n5.hijos=n5h;
		n5.valores=n5v;
		
		int[] n6v = {94,96,99};
		BTN[] n6h = {};
		n6.hijos=n6h;
		n6.valores=n6v;
		
		int[] n7v = {1,4,7};
		BTN[] n7h = {};
		n7.hijos=n7h;
		n7.valores=n7v;
		
		int[] n8v = {9,12,13};
		BTN[] n8h = {};
		n8.hijos=n8h;
		n8.valores=n8v;
		
		int[] n9v = {76,78};
		BTN[] n9h = {};
		n9.hijos=n9h;
		n9.valores=n9v;
		
		int[] n10v = {81,83,85,87};
		BTN[] n10h = {};
		n10.hijos=n10h;
		n10.valores=n10v;
		
		int[] n11v = {90,92};
		BTN[] n11h = {};
		n11.hijos=n11h;
		n11.valores=n11v;
		
		Arbol a = new Arbol();
		a.root=n1;
		
		System.out.println(a.esta(45));
		System.out.println(a.esta(8));
		System.out.println(a.esta(18));
		System.out.println(a.esta(88));
		System.out.println(a.esta(96));
		System.out.println(a.esta(52));
		System.out.println(a.esta(1));
		System.out.println(a.esta(9));
		System.out.println(a.esta(78));
		System.out.println(a.esta(83));
		System.out.println(a.esta(90));
		System.out.println(a.esta(343544650));//false
		
	}
}
