package calculoCoste;

public class Arbol 
{
	BTN root;
	
	public Arbol ()
	{
		this.root=null;
	}
	
	public int coste (String tareas)
	{
		boolean enc=false;
		return this.coste(tareas,root,enc);
	}


	private int coste(String tareas, BTN a, boolean enc) 
	{
		int rdo = 0;
			if (!enc)
			{
				if(a==null)
				{
					//return 0;
				}
				else if(a.element.id.equals(tareas))
				{
					//ir sumando al rdo mientras avanza por los dos lados
					enc=true;
					rdo=rdo+a.element.coste;
					rdo=rdo+this.coste(tareas, a.left, enc);
					rdo=rdo+this.coste(tareas, a.right, enc);
				}
				else
				{
					//ir avanzando hasta encontrar
					rdo=rdo+this.coste(tareas, a.left, enc);
					rdo=rdo+this.coste(tareas, a.right, enc);
				}
			}
			else
			{
				if (a==null)
				{
					//return 0;
				}
				else
				{
					rdo=rdo+a.element.coste;
					rdo=rdo+this.coste(tareas, a.left, enc);
					rdo=rdo+this.coste(tareas, a.right, enc);
				}
			}	
		
		return rdo;
	}


}
