package calculoCoste;

public class BTN 
{
	Tarea element;
	BTN right;
	BTN left;
	
	public BTN (Tarea e)
	{
		this.element=e;
		this.left=null;
		this.right=null;
	}
}
