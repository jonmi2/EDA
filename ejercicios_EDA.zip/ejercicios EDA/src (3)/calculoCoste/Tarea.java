package calculoCoste;

public class Tarea 
{
	String id;
	int coste;
	
	public Tarea (String i, int c)
	{
		this.coste=c;
		this.id=i;
	}
}
