package calculoCoste2;

public class Arbol 
{
	BTN root;
	
	public Arbol() {this.root=null;}
	
	public int coste(String idTarea)
	{
		boolean enc=false;
		return this.coste(idTarea,this.root,enc);
	}

	private int coste(String idTarea, BTN n, boolean enc) 
	{
		int rdo=0;
		if (!enc)
		{	
			if (n==null)
			{
				
			}
			else if (n.elem.id==idTarea)
			{
				enc=true;
				rdo = rdo + n.elem.coste;
				rdo = rdo + this.coste(idTarea, n.left, enc);
				rdo = rdo + this.coste(idTarea, n.right, enc);
			}
			else
			{
				rdo=rdo+this.coste(idTarea, n.left, enc);
				rdo=rdo+this.coste(idTarea, n.right, enc);
			}
		}
		else
		{
			if (n==null)
			{
				
			}
			else 
			{

				rdo = rdo + n.elem.coste;
				rdo = rdo + this.coste(idTarea, n.left, enc);
				rdo = rdo + this.coste(idTarea, n.right, enc);
			}			
		}
		return rdo;
	}
}
