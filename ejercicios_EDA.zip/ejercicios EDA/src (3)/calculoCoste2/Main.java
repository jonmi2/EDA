package calculoCoste2;


public class Main 
{
	public static void main(String[] args)
	{
		BTN n1 = new BTN(new Tarea("T7",5));
		BTN n2 = new BTN(new Tarea("T1",5));
		BTN n3 = new BTN(new Tarea("T3",6));
		BTN n4 = new BTN(new Tarea("T21",5));
		BTN n5 = new BTN(new Tarea("T45",8));
		BTN n6 = new BTN(new Tarea("T54",12));
		BTN n7 = new BTN(new Tarea("T33",5));
		BTN n8 = new BTN(new Tarea("T31",3));
		BTN n9 = new BTN(new Tarea("T12",3));
		BTN n10 = new BTN(new Tarea("T5",5));
		BTN n11 = new BTN(new Tarea("T10",6));
		BTN n12 = new BTN(new Tarea("T8",7));
		BTN n13 = new BTN(new Tarea("T34",2));
		
		n1.left=n2;
		n1.right=n9;
		n2.left=n3;
		n2.right=n6;
		n3.left=n4;
		n3.right=n5;
		n6.left=n7;
		n6.right=n8;
		n9.left=n10;
		n9.right=n12;
		n10.left=n11;
		n10.right=n13;
		
		Arbol a = new Arbol();
		
		a.root=n1;
		
		System.out.println(+a.coste("T31"));//debe dar 3
		System.out.println(a.coste("T12"));//debe dar 23
		System.out.println(a.coste("T7"));//debe dar 72
		System.out.println(a.coste("T1"));//debe dar 44
		System.out.println(a.coste("T1111"));// debe dar 0
		
		
		Arbol b = new Arbol();
		
		BTN b1 = new BTN(new Tarea("T7",5));
		BTN b2 = new BTN(new Tarea("T1",5));
		BTN b3 = new BTN(new Tarea("T3",6));
		
		b1.left=b2;
		b1.right=b3;
		
		b.root=b1;
		
		System.out.println(b.coste("T7"));//debe dar 16
		System.out.println(b.coste("T1"));//debe dar 5
		System.out.println(b.coste("T3"));//debe dar 6
		System.out.println(b.coste("T31"));//debe dar 0
	}
}
