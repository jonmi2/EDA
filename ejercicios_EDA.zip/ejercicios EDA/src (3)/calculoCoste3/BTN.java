package calculoCoste3;

public class BTN 
{
	Tarea elem;
	BTN left;
	BTN right;
	
	public BTN(Tarea e)
	{
		this.elem=e;
		this.left=null;
		this.right=null;
	}
}
