package diccionario;

import java.util.ArrayList;
import java.util.Iterator;

public class ArbolDiccionario 
{
	Nodo root;
	
	public ArbolDiccionario()
	{
		this.root=null;
	}
	
	public int contarPalabras(char[] prefijo)
	{
		int rdo = 0;
		ArrayList<String> palabras = new ArrayList<String>();
		String p = "";
		this.contarPalabras(prefijo, this.root, palabras, p);
		rdo = palabras.size();
		Iterator<String> itr = palabras.iterator();
		while (itr.hasNext())
		{
			String a = itr.next();
			System.out.println(a);
		}
		return rdo;
	}

	private void contarPalabras(char[] prefijo, Nodo a, ArrayList<String> palabras, String p) 
	{
		if (a==null)
		{
			
		}
		else if (a.es)//tiene asterisco-->es palabra
		{
			String comp =p+a.valor;
			if (p.contains(String.valueOf(prefijo)))
			{
				palabras.add(comp);
			}		
		}
		else
		{
			p=p+a.valor;
			this.contarPalabras(prefijo, a.left, palabras,  p);
			this.contarPalabras(prefijo, a.right, palabras,  p);
		}
		
	}

	
}
