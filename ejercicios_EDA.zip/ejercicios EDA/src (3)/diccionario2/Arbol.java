package diccionario2;

import java.util.ArrayList;

public class Arbol 
{
	Nodo root;
	
	public Arbol()
	{
		this.root=null;
	}
	
	public int contarPalabras(char[] prefijo)
	{
		ArrayList<String> rdo= new ArrayList<String>();
		String p = "";
		return this.contarPalabras(prefijo,this.root,rdo,p);		
	}

	private int contarPalabras(char[] prefijo, Nodo n, ArrayList<String> rdo, String p) 
	{
		if (n==null)
		{
			
		}
		else
		{
			p=p+n.valor;
			if (n.es && p.contains(new String(prefijo))) {rdo.add(p);}
			this.contarPalabras(prefijo,n.left,rdo,p);
			this.contarPalabras(prefijo,n.right,rdo,p);
		}
		return rdo.size();
	}
}
