package diccionario2;


public class Main 
{
	public static void main(String[] args)
	{
		Nodo n1 = new Nodo('c', false);
		Nodo n2 = new Nodo('a', false);
		Nodo n3 = new Nodo('s', false);
		Nodo n4 = new Nodo('a', true);
		Nodo n5 = new Nodo('o', true);
		Nodo n6 = new Nodo('o', false);
		Nodo n7 = new Nodo('z', true);
		Nodo n8 = new Nodo('c', false);
		Nodo n9 = new Nodo('a', true);
		n1.left=n2;
		n2.left=n3;
		n3.left=n4;
		n3.right=n5;
		n1.right=n6;
		n6.left=n7;
		n6.right=n8;
		n8.right=n9;
		
		Arbol arbol = new Arbol();
		arbol.root=n1;
		
		
		
		char[] c1 = new char[1];
		c1[0]='c';
		
		char[] c2 = new char[3];
		c2[0]='c';
		c2[1]='a';
		c2[2]='s';
		
		char[] c3 = new char[2];
		c3[0]='c';
		c3[1]='o';
		
		char[] c4 = new char[4];
		c4[0]='c';
		c4[1]='a';
		c4[2]='s';
		c4[3]='a';
		
		/*String casa = "casa";
		System.out.println(casa.contains(new String(c1)));
		System.out.println();
		System.out.println();*/
		
		
		
		int rdo1 = arbol.contarPalabras(c1);
		System.out.println("el resultado con 'c' es:   "+ rdo1);
		int rdo2 = arbol.contarPalabras(c2);
		System.out.println("el resultado con 'cas' es:   "+ rdo2);
		int rdo3 = arbol.contarPalabras(c3);	
		System.out.println("el resultado con 'co' es:   "+ rdo3);
		int rdo4 = arbol.contarPalabras(c4);	
		System.out.println("el resultado con 'casa' es:   "+ rdo4);
		
	}
}
