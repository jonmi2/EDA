package diccionario3;

import java.util.ArrayList;
import java.util.Iterator;

public class Arbol 
{
		Nodo root;
		
		public Arbol()
		{
			this.root=null;
		}
		
		public int contarPalabras(char[] prefijo)
		{
			int ps=0;
			String p = "";
			ArrayList<String> rdo=new ArrayList<String>();
			this.contarPalabras(prefijo,rdo,this.root,p);
			Iterator<String> itr = rdo.iterator();
			while (itr.hasNext())
			{
				String pa =itr.next();
				if (pa.contains(new String(prefijo))) {ps++;}
			}
			return ps;
		}

		private void contarPalabras(char[] prefijo, ArrayList<String> rdo, Nodo n, String p) 
		{
			if (n==null)
			{
				
			}
			else if (n.es) 
			{
				p=p+n.valor;
				rdo.add(p);
				this.contarPalabras(prefijo, rdo, n.left, p);
				this.contarPalabras(prefijo, rdo, n.right, p);
			}
			else
			{
				p=p+n.valor;
				this.contarPalabras(prefijo, rdo, n.left, p);
				this.contarPalabras(prefijo, rdo, n.right, p);
			}						
		}
}
