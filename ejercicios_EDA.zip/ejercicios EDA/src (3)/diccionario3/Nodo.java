package diccionario3;


public class Nodo 
{
	Character valor;
	Boolean es;
	Nodo left;
	Nodo right;
	
	public Nodo (Character v, boolean t)
	{
		this.valor=v;
		if (t) 
		{
			this.es=true;
		}
		else
		{
			this.es=false;
		}
		this.left=null;
		this.right=null;
	}
}
