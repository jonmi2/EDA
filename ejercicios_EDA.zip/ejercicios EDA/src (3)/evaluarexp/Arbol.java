package evaluarexp;

import java.util.HashMap;

public class Arbol 
{
	BinaryTreeNode<InfoElemExp> root;
	
	public Arbol()
	{
		this.root=null;
	}
	
	public Integer evaluar(HashMap<String, Integer> t)
	{
    // pre: tHash contiene los valores de las variables
    // post: Se ha evaluado la expresi�n correspondiente al �rbol
    //       Los valores de las variables se han tomado de tHash
    //       Si una variable del �rbol no se encuentra en la 
    //       tabla hash, se asumir� que el valor por defecto es cero
		return evaluar(t, root);
	}

	private Integer evaluar(HashMap<String, Integer> t, BinaryTreeNode<InfoElemExp> a) 
	{
		if (!a.elem.operador)//la raiz es una variable
		{
			return valor(a.elem.elem,t);
		}
		else //la raiz es un operador
		{
			int izq = evaluar(t,a.left);
			int der = evaluar(t,a.right);
			if (a.elem.elem.equals("*"))
			{
				return izq*der;
			}
			else
			{
				return izq+der;
			}
		}
	}

	private Integer valor(String elem, HashMap<String, Integer> t)
	{
		return t.get(elem);
	}
	
	public void print(){
		print(root);
	}
	
	private void print(BinaryTreeNode<InfoElemExp> n)
	{
		if (n != null)
		{
			if (!n.elem.operador) { System.out.print(n.elem.elem);}
			else 
			{ 
				System.out.print("(");
  			  	print(n.left);
  			  	System.out.print(n.elem.elem);
  			  	if (!n.elem.operador)
  			  	{
  			  		System.out.print("vble");
  			  	}
  			  	else
  			  	{
  			  		System.out.print("operador");
  			  	}
  			  	print(n.right);
  			  	System.out.print(")");
			}
		}
	}
}
