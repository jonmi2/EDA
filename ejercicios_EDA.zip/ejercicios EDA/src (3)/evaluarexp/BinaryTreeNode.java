package evaluarexp;

public class BinaryTreeNode<T> 
{
	T elem;
	BinaryTreeNode<T> left;
	BinaryTreeNode<T> right;
	
	public BinaryTreeNode (T e)
	{
		this.elem=e;
	}
}
