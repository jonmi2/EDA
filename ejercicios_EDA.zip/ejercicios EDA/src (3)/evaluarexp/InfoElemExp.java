package evaluarexp;

public class InfoElemExp 
{
	 String elem;       // *, +, � nombre de una variable
	 boolean operador; // true �> operador, false �> variable
	 
	 public InfoElemExp(String e, boolean o)
	 {
		 this.elem=e;
		 this.operador=o;
	 }
}
