package evaluarexp;

import java.util.HashMap;

public class Main 
{
	public static void main(String[] args)
	{
		Arbol a = new Arbol();
		HashMap<String, Integer> th = new HashMap<String, Integer>();
		
		BinaryTreeNode<InfoElemExp> n1 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("*", true));
		BinaryTreeNode<InfoElemExp> n2 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("+", true));
		BinaryTreeNode<InfoElemExp> n3 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("*", true));
		BinaryTreeNode<InfoElemExp> n4 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("*", true));
		BinaryTreeNode<InfoElemExp> n5 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("+", true));
		BinaryTreeNode<InfoElemExp> n6 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("+", true));
		BinaryTreeNode<InfoElemExp> n7 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("d", false));
		BinaryTreeNode<InfoElemExp> n8 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("x", false));
		BinaryTreeNode<InfoElemExp> n9 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("a", false));
		BinaryTreeNode<InfoElemExp> n10 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("s", false));
		BinaryTreeNode<InfoElemExp> n11 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("g", false));
		BinaryTreeNode<InfoElemExp> n12 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("a", false));
		BinaryTreeNode<InfoElemExp> n13 = new BinaryTreeNode<InfoElemExp>(new InfoElemExp("m", false));

		//                *
		//              /   \
		//             /     \
		//            /       \
		//            +        *
		//          /   \     / \
		//          *    +    +  d
		//         / \  / \  / \ 
		//         x a  s g  a m
		// Representa: ((x * a) + (s + g)) * ((a + m) * d)
		// El resultado es: 560
	
		a.root     = n1;
		n1.left  = n2;
		n1.right = n3;
		n2.left  = n4;
		n2.right = n5;
		n3.left  = n6;
		n3.right = n7;
		n4.left  = n8;
		n4.right = n9;
		n5.left  = n10;
		n5.right = n11;
		n6.left  = n12;
		n6.right = n13;
		
		th.put("x",  4);
		th.put("a",  5);
		th.put("s",  7);
		th.put("g",  1);
		th.put("m",  5);
		th.put("d",  2);
		
		int rdo = a.evaluar(th);
		
		
		System.out.println("primero imprimir el arbol    ");
		a.print();
		System.out.println("");
		System.out.println("despues el resultado --- ");
		System.out.println("el resultado essss    "+ rdo);
		
		
	}
}
