package evaluarexpapel;

public class Arbol 
{
	BTN<InfoElemExp> root;
	
	public Arbol ()
	{
		this.root=null;
	}
	
	public int evaluar(ArbolVbles aV)
	{		
		return this.evaluar(aV,root);
	}

	private int evaluar(ArbolVbles aV, BTN<InfoElemExp> a) 
	{
		 if (!a.element.operador)//es una variable
		{
			return aV.buscar(a.element.elem);
		}
		else
		{
			int izq = this.evaluar(aV, a.left);
			int der = this.evaluar(aV, a.right);
			if (a.element.elem.equals("*"))
			{
				return izq*der;
			}
			else
			{
				return izq+der;
			}			
		}
	}
	
}