package evaluarexpapel;

public class ArbolVbles
{
	BTN<InfoElemVble> root;
	
	public ArbolVbles()
	{
		this.root=null;
	}

	public int buscar(String elem) 
	{
		int rdo = this.buscar(elem,root);
		return rdo;
	}

	private int buscar(String elem, BTN<InfoElemVble> a) 
	{
		boolean enc = false;
		while (!enc && a!=null)
		{	
			if (a.element.nom.compareTo(elem)==0)
			{
				enc=true;
			}
			else if (a.element.nom.compareTo(elem)>0) //a.element.nom va antes en el diccionario que elem
			{
				a=a.left;
			}
			else  //a.element.nom va despues en el diccionario que elem
			{
				a=a.right;
			}
			
			if (enc)
			{
				return a.element.valor;
			}
			else
			{
				return 0;
			}
		}
		return 0;
	}
		
}
