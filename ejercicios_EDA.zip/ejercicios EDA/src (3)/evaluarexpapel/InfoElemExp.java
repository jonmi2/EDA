package evaluarexpapel;

public class InfoElemExp 
{
	String elem;
	boolean operador;
	
	public InfoElemExp(String e, boolean b)
	{
		this.elem=e;
		if(b)
		{
			this.operador=true;
		}
		else
		{
			this.operador=false;
		}
	}
}
