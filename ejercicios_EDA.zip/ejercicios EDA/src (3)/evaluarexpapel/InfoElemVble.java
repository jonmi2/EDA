package evaluarexpapel;

public class InfoElemVble 
{
	String nom;
	int valor;
	
	public InfoElemVble(String n, int v)
	{
		this.valor=v;
		this.nom=n;
	}
}
