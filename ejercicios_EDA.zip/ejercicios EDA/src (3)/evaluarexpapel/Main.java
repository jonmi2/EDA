package evaluarexpapel;

public class Main 
{
	public static void main(String[] args)
	{
		
		BTN<InfoElemVble> i1 = new BTN<InfoElemVble> (new InfoElemVble("kont",5));
		BTN<InfoElemVble> i2 = new BTN<InfoElemVble> (new InfoElemVble("d",2));
		BTN<InfoElemVble> i3 = new BTN<InfoElemVble> (new InfoElemVble("a",5));
		BTN<InfoElemVble> i4 = new BTN<InfoElemVble> (new InfoElemVble("ant",45));
		BTN<InfoElemVble> i5 = new BTN<InfoElemVble> (new InfoElemVble("h",1));
		BTN<InfoElemVble> i6 = new BTN<InfoElemVble> (new InfoElemVble("g",1));
		BTN<InfoElemVble> i7 = new BTN<InfoElemVble> (new InfoElemVble("s2",7));
		BTN<InfoElemVble> i8 = new BTN<InfoElemVble> (new InfoElemVble("m",11));
		BTN<InfoElemVble> i9 = new BTN<InfoElemVble> (new InfoElemVble("l",9));
		BTN<InfoElemVble> i10 = new BTN<InfoElemVble> (new InfoElemVble("x1",4));
		
		i1.left=i2;
		i2.left=i3;
		i3.right=i4;
		i2.right=i5;
		i5.left=i6;
		i1.right=i7;
		i7.right=i10;
		i7.left=i8;
		i8.left=i9;
		
		ArbolVbles aV = new ArbolVbles();
		aV.root=i1;
		
		System.out.println(aV.buscar("a"));
		System.out.println(aV.buscar("x1"));
		System.out.println(aV.buscar("jorrrr"));
		System.out.println(aV.buscar("g"));
		System.out.println(aV.buscar("ant"));
		
	}
}
