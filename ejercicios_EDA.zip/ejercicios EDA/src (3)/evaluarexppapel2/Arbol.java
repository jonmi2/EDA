package evaluarexppapel2;



public class Arbol 
{
	BTN<InfoElemExp> root;
	
	public Arbol ()
	{
		this.root=null;
	}
	
	public int evaluar(ArbolVbles aV)
	{
		
		return this.evaluar(aV, this.root);
	}

	private int evaluar(ArbolVbles aV, BTN<InfoElemExp> n) 
	{
		int rdo=0;
		if (n.element.operador)
		{
			if (n.element.elem.equals("*"))
			{
				rdo=rdo+(this.evaluar(aV, n.left)*this.evaluar(aV, n.right));
			}
			else
			{
				rdo=rdo+(this.evaluar(aV, n.left)+this.evaluar(aV, n.right));
			}
		}
		else
		{
			return aV.valor(n.element.elem);
		}	
		return rdo;
	}
}
