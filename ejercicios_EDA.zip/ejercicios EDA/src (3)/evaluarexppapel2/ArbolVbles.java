package evaluarexppapel2;


public class ArbolVbles 
{
	BTN<InfoElemVble> root;
	
	public ArbolVbles()
	{
		this.root=null;
	}

	public int valor(String elem) 
	{
		boolean enc=false;
		return this.valor(elem,this.root,enc);
	}

	private int valor(String elem, BTN<InfoElemVble> n, boolean enc) //devuelve el valor de la vble
	{
		if (n==null)
		{
			return 0;
		}
		else if (n.element.nom.compareTo(elem)<0)
		{
			return this.valor(elem, n.right, enc);
		}
		else if (n.element.nom.compareTo(elem)>0)
		{
			return this.valor(elem, n.left, enc);
		}
		else
		{
			return n.element.valor;
		}
	}

}
