package evaluarexppapel2;


public class BTN<T> 
{
	T element;
	BTN<T> right;
	BTN<T> left;
	
	public BTN(T elem)
	{
		this.element=elem;
		this.right=null;
		this.left=null;
	}
}
