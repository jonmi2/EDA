package evaluarexppapel2;

import java.util.HashMap;


public class Main 
{
	public static void main(String[] args)
	{
		BTN<InfoElemVble> i1 = new BTN<InfoElemVble> (new InfoElemVble("kont",5));
		BTN<InfoElemVble> i2 = new BTN<InfoElemVble> (new InfoElemVble("d",2));
		BTN<InfoElemVble> i3 = new BTN<InfoElemVble> (new InfoElemVble("a",5));
		BTN<InfoElemVble> i4 = new BTN<InfoElemVble> (new InfoElemVble("ant",45));
		BTN<InfoElemVble> i5 = new BTN<InfoElemVble> (new InfoElemVble("h",1));
		BTN<InfoElemVble> i6 = new BTN<InfoElemVble> (new InfoElemVble("g",1));
		BTN<InfoElemVble> i7 = new BTN<InfoElemVble> (new InfoElemVble("s2",7));
		BTN<InfoElemVble> i8 = new BTN<InfoElemVble> (new InfoElemVble("m",11));
		BTN<InfoElemVble> i9 = new BTN<InfoElemVble> (new InfoElemVble("l",9));
		BTN<InfoElemVble> i10 = new BTN<InfoElemVble> (new InfoElemVble("x1",4));
		
		i1.left=i2;
		i2.left=i3;
		i3.right=i4;
		i2.right=i5;
		i5.left=i6;
		i1.right=i7;
		i7.right=i10;
		i7.left=i8;
		i8.left=i9;
		
		ArbolVbles aV = new ArbolVbles();
		aV.root=i1;
		
		Arbol a = new Arbol();
		
		BTN<InfoElemExp> n1 = new BTN<InfoElemExp>(new InfoElemExp("*", true));
		BTN<InfoElemExp> n2 = new BTN<InfoElemExp>(new InfoElemExp("+", true));
		BTN<InfoElemExp> n3 = new BTN<InfoElemExp>(new InfoElemExp("*", true));
		BTN<InfoElemExp> n4 = new BTN<InfoElemExp>(new InfoElemExp("*", true));
		BTN<InfoElemExp> n5 = new BTN<InfoElemExp>(new InfoElemExp("+", true));
		BTN<InfoElemExp> n6 = new BTN<InfoElemExp>(new InfoElemExp("+", true));
		BTN<InfoElemExp> n7 = new BTN<InfoElemExp>(new InfoElemExp("d", false));
		BTN<InfoElemExp> n8 = new BTN<InfoElemExp>(new InfoElemExp("x1", false));
		BTN<InfoElemExp> n9 = new BTN<InfoElemExp>(new InfoElemExp("a", false));
		BTN<InfoElemExp> n10 = new BTN<InfoElemExp>(new InfoElemExp("s2", false));
		BTN<InfoElemExp> n11 = new BTN<InfoElemExp>(new InfoElemExp("g", false));
		BTN<InfoElemExp> n12 = new BTN<InfoElemExp>(new InfoElemExp("a", false));
		BTN<InfoElemExp> n13 = new BTN<InfoElemExp>(new InfoElemExp("kont", false));

		//                *
		//              /   \
		//             /     \
		//            /       \
		//            +        *
		//          /   \     / \
		//          *    +    +  d
		//         / \  / \  / \ 
		//         x a  s g  a m
		// Representa: ((x * a) + (s + g)) * ((a + m) * d)
		// El resultado es: 560
		
		a.root     = n1;
		n1.left  = n2;
		n1.right = n3;
		n2.left  = n4;
		n2.right = n5;
		n3.left  = n6;
		n3.right = n7;
		n4.left  = n8;
		n4.right = n9;
		n5.left  = n10;
		n5.right = n11;
		n6.left  = n12;
		n6.right = n13;
		
		System.out.println(a.evaluar(aV));
	}
}
