package paralelos2;

import java.util.ArrayList;


public class Arbol 
{
	public Nodo rootAps;
	public Nodo rootNom;
	
	public Arbol()
	{
		this.rootAps=null;
		this.rootNom=null;
	}
	
	public ArrayList<String> obtenerListaOrdenada()
	{
		ArrayList<String> rdo = new ArrayList<String>();
		return obtenerListaOrdenada(this.rootAps,this.rootNom,rdo);
	}

	private ArrayList<String> obtenerListaOrdenada(Nodo nA, Nodo nN, ArrayList<String> rdo) 
	{
		if (nA==null && nN==null)
		{
			
		}
		else
		{
			if ((nA.left==null && nN.left==null)  &&	(nA.right==null && nN.right==null))
			{
				rdo.add(nA.valor+"--"+nN.valor);
			}
			else 
			{
				this.obtenerListaOrdenada(nA.left, nN.left, rdo);
				rdo.add(nA.valor+"--"+nN.valor);
				this.obtenerListaOrdenada(nA.right, nN.right, rdo);
			}
		}
		
		return rdo;
	}
}
