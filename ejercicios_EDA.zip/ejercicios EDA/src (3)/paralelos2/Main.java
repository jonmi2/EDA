package paralelos2;

import java.util.ArrayList;
import java.util.Iterator;

public class Main 
{
	public static void main(String[] args)
	{
		Arbol arbol = new Arbol();
		
		Nodo n1 = new Nodo("Abaitua");
		Nodo n2 = new Nodo("Dieguez");
		Nodo n3 = new Nodo("Duran");
		Nodo n4 = new Nodo("Enriquez");
		Nodo n5 = new Nodo("Fernandez");
		Nodo n6 = new Nodo("Goenaga");
		Nodo n7 = new Nodo("Illara");
		Nodo n8 = new Nodo("Martinez");
		Nodo n9 = new Nodo("Orue");
		Nodo n10 = new Nodo("Perez");
		Nodo n11 = new Nodo("Sartxaga");
		Nodo n12 = new Nodo("Vazquez");
		
		n2.left=n1;
		n2.right=n4;
		n4.left=n3;
		n5.left=n2;
		n5.right=n12;
		n6.right=n7;
		n10.left=n9;
		n10.right=n11;
		n8.left=n6;
		n8.right=n10;
		n12.left=n8;
		
		Nodo a1 = new Nodo("pedro");
		Nodo a2 = new Nodo("luis");
		Nodo a3 = new Nodo("naiara");
		Nodo a4 = new Nodo("amaia");
		Nodo a5 = new Nodo("ana");
		Nodo a6 = new Nodo("patxi");
		Nodo a7 = new Nodo("arantza");
		Nodo a8 = new Nodo("miren");
		Nodo a9 = new Nodo("itziar");
		Nodo a10 = new Nodo("jose");
		Nodo a11 = new Nodo("maria");
		Nodo a12 = new Nodo("jon");
		
		a2.left=a1;
		a2.right=a4;
		a4.left=a3;
		a5.left=a2;
		a5.right=a12;
		a6.right=a7;
		a10.left=a9;
		a10.right=a11;
		a8.left=a6;
		a8.right=a10;
		a12.left=a8;
		
		arbol.rootAps=n5;
		arbol.rootNom=a5;
		
		ArrayList<String> rdo = arbol.obtenerListaOrdenada();
		Iterator<String> it = rdo.iterator();
		int i=1;
		while (it.hasNext())
		{
			String s = it.next();
			System.out.print(i+"  :");
			System.out.println(s);
			i++;
		}

	}
}
