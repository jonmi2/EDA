package paralelos3;

import java.util.ArrayList;



public class Arbol 
{
	public Nodo rootAps;
	public Nodo rootNom;
	
	public Arbol()
	{
		this.rootAps=null;
		this.rootNom=null;
	}
	
	public ArrayList<String> obtenerListaOrdenada()
	{
		ArrayList<String> rdo = new ArrayList<String>();
		this.obtenerListaOrdenada(this.rootAps,this.rootNom,rdo);
		return rdo;
	}

	private void obtenerListaOrdenada(Nodo aps, Nodo noms, ArrayList<String> rdo) 
	{
		if (aps==null && noms==null)
		{
			
		}
		else
		{
			this.obtenerListaOrdenada(aps.left, noms.left, rdo);
			rdo.add(noms.valor+" -"+aps.valor);
			this.obtenerListaOrdenada(aps.right, noms.right, rdo);
		}	
	}
}
