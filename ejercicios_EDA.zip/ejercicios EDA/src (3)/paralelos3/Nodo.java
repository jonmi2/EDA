package paralelos3;


public class Nodo 
{
	String valor;
	Nodo left;
	Nodo right;
	
	public Nodo(String v)
	{
		this.valor=v;
		this.right=null;
		this.left=null;	
	}
}
