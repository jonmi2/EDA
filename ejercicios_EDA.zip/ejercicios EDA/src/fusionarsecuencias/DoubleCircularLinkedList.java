package fusionarsecuencias;

import listasimetrica.DoubleNode;

public class DoubleCircularLinkedList 
{
	public DoubleNode<String> first;
	
	public DoubleCircularLinkedList() 
	{
		this.first=null;
	}
	
	public void fusionarSecuencias(String[] s1, String[] s2)
	{
		//pre:s1 y s2 est�n ordenadas
		//la lista de salida estar� ordenada tmb
		int i1 = 0;
		int i2 = 0;
		DoubleNode<String> act = new DoubleNode<String>(null);
		DoubleNode<String> cop = new DoubleNode<String>(null);
		
		
		while (i1<s1.length && i2<s2.length)		
		{
			if(s1[i1].compareTo(s2[i2])<0)
			{
				act.data=s1[i1];
				act.next=new DoubleNode<String>(null);
				act.next.prev=act;
				act=act.next;
				i1++;
			}
			else
			{
				act.data=s2[i2];
				act.next=new DoubleNode<String>(null);
				act.next.prev=act;
				act=act.next;
				i2++;
			}
		}
		if(i1<s1.length)
		{
			while (i1<s1.length)
			{
				act.data=s1[i1];
				act.next=new DoubleNode<String>(null);
				act.next.prev=act;
				act=act.next;
				i1++;
			}
		}
		else if(i2<s2.length)
		{
			while (i2<s2.length)
			{
				act.data=s2[i2];
				act.next=new DoubleNode<String>(null);
				act.next.prev=act;
				act=act.next;
				i2++;
			}
		}
		act=act.prev;
		cop=act;
		while(cop.prev!=null)
		{
			cop=cop.prev;
		}
		cop.prev=act;
		act.next=cop;	
		first=cop;		
	}
	
	
	public void imprimir()
	{
		System.out.println(first.data);
		DoubleNode<String> act = first.next;
		while (act!=first)
		{
			System.out.println(act.data);
			act=act.next;
		}
	}
	
}
