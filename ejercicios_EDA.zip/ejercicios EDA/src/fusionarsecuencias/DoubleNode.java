package fusionarsecuencias;

public class DoubleNode<T> 
{
	public T data;
	public DoubleNode<T> prev;
	public DoubleNode<T> next;
	
	public DoubleNode(T elem)
	{
		this.data=elem;
		this.prev=null;
		this.next=null;
	}
	
}
