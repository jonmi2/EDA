package listaenlazada;

public class Link 
{
    public Persona data;
    public Link next;
	
	public Link(Persona p)
	{
		data=p;
		next=null;
	}
	
	/*public void setNext(Link pLink)
	{
		this.next=pLink;
	}
	
	public Persona getData()
	{
		return this.data;
	}
	
	public Link getNext()
	{
		return this.next;
	}*/
}
