package listaenlazada;

public class LinkList 
{
	private Link first;
	
	public LinkList()
	{
		first=null;
	}
	
	public boolean isEmpty()
	{
		if(this.first==null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void insertFirst(Persona p)
	{
		Link nuevo = new Link(p);
		nuevo.next=first;
		this.first=nuevo;
	}
	
	public Persona deleteFirst()
	{
		if (this.isEmpty())
		{
			return null;
		}
		else
		{
			Persona p = first.data;
			this.first=this.first.next;
			return p;
		}
	}
	
	public void imprimir()
	{
		if (this.isEmpty())
		{
			System.out.println("lista vacia");
		}
		else
		{
			Link act = this.first;
			while (act!=null)
			{
				System.out.println(act.data.getNombre());
				act=act.next;
			}
		}
	}
	
	
	public Persona find (Persona p)
	{
		
		if (this.isEmpty())
		{
			System.out.println("no est� porq la lista es vac�a");
			return null;
		}
		else
		{
			Link act = this.first;
			boolean enc = false;
			while (!enc && act!=null)
			{
				if (act.data.equals(p))
				{
					enc=true;
				}
				else
				{
					act=act.next;
				}
			}
			if (enc==false)
			{
				System.out.println("no se ha encontrado");
				return null;
			}
			else
			{
				System.out.println("la persona "+act.data.getNombre()+" si est�");
				return act.data;
			}
		}
		
	}
	
	public Persona delete(Persona p)
	{
		Link ant = null;
		Link act = this.first;
		boolean enc=false;
		while(!enc && act!=null)
		{
			if(act.data.equals(p))
			{				
				enc=true;			
			}
			else
			{
				ant=act;
				act=act.next;
			}
		}
		if (enc==false)
		{
			System.out.println("no se ha borrado ya que no se ha encontrado");
			return null;
		}
		else
		{
			if (act==first)
			{
				this.first=first.next;
				System.out.println("se ha borrado a "+act.data.getNombre());
				return act.data;
			}
			else
			{
				ant.next=act.next;
				System.out.println("se ha borrado a "+act.data.getNombre());
				return act.data;
			}
			
		}
	}
	
	public void insertLast(Persona p)
	{
		Link nuevo = new Link(p); 
		if (this.isEmpty())
		{			
			this.first=nuevo;
		}
		else
		{
			Link act = this.first;
			while (act.next!=null)
			{
				act=act.next;
			}
			act.next=nuevo;
		}
	}
	
}
