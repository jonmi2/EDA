package listaenlazada;

public class ListaDeProveedores 
{
	public Nodo first;
	
	public ListaDeProveedores() {this.first=null;}
	
	public void eliminarProveedor(String prov)
	{
		//el proveedor est� y no es el �nico de su nivel. ninguno de nivel inferior le apunta.
		boolean enc= false;		
		boolean vuelta= false;	
		Nodo prev = first;
		Nodo act = first.sigP;	
		
	while (!enc)
	{
		if (act.nombre==prov && act.equals(first))
		{
			first=act.sigP;
			enc=true;
		}
		else if (act.nombre==prov)
		{
			enc=true;
		}
		else if(!enc && vuelta)
		{
			if (act.hasSup())
			{
				prev=prev.sigP;
				act=act.sup;
				vuelta=false;
			}
			else
			{
				while (!act.hasSup())
				{
					prev=prev.sigP;
					act=act.sigP;
				}
				if (act.hasSup())
				{
					prev=prev.sigP;
					act=act.sup;
					vuelta=false;
				}
			}
		}
		else if(act.nombre!=prov && act.equals(first))
		{
			vuelta=true;
		}
		else if (act.nombre!=prov)
		{
			prev=act;
			act=act.sigP;
		}
	}
	if(enc)
	{
		prev.sigP=act.sigP;
	}
	
}
	
	
	public void imprimirLista()
	{
		Nodo act = first.sigP;
		Nodo palo = first;

		while (act.sigP!=null)
		{
			while (act!=palo)
			{
				System.out.println(act.nombre);
				act=act.sigP;
			}
			if (act==palo)
			{
				System.out.println(act.nombre);
				if (act.hasSup())
				{
					palo=act.sup;
					if (act.sup.sigP!=null)
					{
						act=act.sup.sigP;
					}
					else
					{
						act=palo;
					}					
				}
				else
				{
					while(!act.hasSup())
					{
						act=act.sigP;
					}
					act=act.sup.sigP;
					palo=act;
				}
			}
		}
		System.out.println(palo.nombre);
		
	}
	
}
