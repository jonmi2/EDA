package listaenlazada;

public class Main 
{
	public static void main(String[] args) 
	 {
		
		//prueba instertFisrt, deleteFirst, imprimir
		/*
		LinkList lista = new LinkList();
		
		System.out.println("imprimiremos la lista vacia");
		lista.imprimir();
		
		
		System.out.println("---------");
		Persona p1 = new Persona("jon","1");
		Persona p2 = new Persona("unai","2");
		Persona p3 = new Persona("messi","3");
		Persona p4 = new Persona("cris","4");
		
		lista.insertFirst(p4);
		lista.insertFirst(p3);
		lista.insertFirst(p2);
		lista.insertFirst(p1);
		
		System.out.println("imprimiremos la lista con 4 personas");
		
		lista.imprimir();
		
		lista.deleteFirst();
		System.out.println("-------");
		System.out.println("imprimiremos la lista con 3 personas (se ha eliminado el primero)");
		
		lista.imprimir();
		*/
		
		/*
		//prueba buscar
		LinkList lista = new LinkList();
		
		System.out.println("buscar en la lista vacia");
		lista.imprimir();
		Persona p0 = new Persona("jjjj","0");
		lista.find(p0);
		
		
		System.out.println("---------");
		Persona p1 = new Persona("jon","1");
		Persona p2 = new Persona("unai","2");
		Persona p3 = new Persona("messi","3");
		Persona p4 = new Persona("cris","4");
		
		lista.insertFirst(p4);
		lista.insertFirst(p3);
		lista.insertFirst(p2);
		lista.insertFirst(p1);
		
		System.out.println("buscar en la lista con 4 personas");
		
		
		System.out.println("-------");
		System.out.println("tiene q decir q no est�");
		lista.find(p0);
		
		System.out.println("ahora tiene q decir q si est�");
		lista.find(p3);
		*/
		
		//prueba borrar
		/*LinkList lista = new LinkList();
		
		System.out.println("borrar en la lista vacia");
		Persona p0 = new Persona("jjjj","0");
		lista.delete(p0);
		
		
		System.out.println("---------");
		Persona p1 = new Persona("jon","1");
		Persona p2 = new Persona("unai","2");
		Persona p3 = new Persona("messi","3");
		Persona p4 = new Persona("cris","4");
		
		lista.insertFirst(p4);
		lista.insertFirst(p3);
		lista.insertFirst(p2);
		lista.insertFirst(p1);
		
		System.out.println("borrar en la lista con 4 personas");
		
		
		System.out.println("-------");
		System.out.println("tiene q decir q no se ha borrado porq no est�");
		lista.delete(p0);
		lista.imprimir();
		
		System.out.println("ahora tiene q decir q si ha borrado ha messi");
		lista.delete(p3);
		lista.imprimir();
		
		//prueba insertLast
		LinkList lista = new LinkList();
		Persona p0 = new Persona("jjjj","0");
	    
		System.out.println("a�adir en la lista vacia");	
		lista.insertLast(p0);
		lista.imprimir();
		
		System.out.println("---------");
		Persona p1 = new Persona("jon","1");
		Persona p2 = new Persona("unai","2");
		Persona p3 = new Persona("messi","3");
		Persona p4 = new Persona("cris","4");
		
		lista.insertFirst(p4);
		lista.insertFirst(p3);
		lista.insertFirst(p2);
		lista.insertFirst(p1);
		
		System.out.println("insertar en la lista con 4 personas");		
		System.out.println("-------");
		lista.insertLast(p0);
		lista.imprimir();*/
		
		ListaDeProveedores lista = new ListaDeProveedores();
		
		
		Nodo n1= new Nodo("A",3);
		Nodo n2= new Nodo("B",4);
		Nodo n3= new Nodo("C",6);
		Nodo n4= new Nodo("D",7);
		Nodo n5= new Nodo("P",8);
		Nodo n6= new Nodo("Q",3);
		Nodo n7= new Nodo("R",4);
		Nodo n8= new Nodo("U",5);
		
		n1.sigP=n2;
		n2.sigP=n3;
		n3.sigP=n4;
		n4.sigP=n1;
		n5.sigP=n6;
		n6.sigP=n7;
		n7.sigP=n5;
		n1.sup=n5;
		n4.sup=n7;
		n5.sup=n8;
		n7.sup=n8;
		
		lista.first=n1;
		
		/*System.out.println("trueee   "+n1.hasSup());
		System.out.println("falseeeee   "+n2.hasSup());
		System.out.println("falseeee   "+n6.hasSup());*/
		
		System.out.println("La lista antes de borrar");
		
		lista.imprimirLista();
		
		lista.eliminarProveedor("Q");
		
		System.out.println("La lista despues de borrar");
		
		lista.imprimirLista();
		
    }
}
