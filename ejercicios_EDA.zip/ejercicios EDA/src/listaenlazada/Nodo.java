package listaenlazada;

public class Nodo 
{
	public String nombre;
	public int cantidad;
	public Nodo sigP;
	public Nodo sup;
	
	public Nodo(String pNom, int pCant)
	{
		this.cantidad=pCant;
		this.nombre=pNom;
	}
	
	public boolean hasSup()
	{
		if (sup==null) {return false;}
		else {return true;}
	}
}
