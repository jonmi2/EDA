package listaenlazada;

public class Persona 
{
	private String nombre;
	private String dni;
	
	public Persona(String pNom, String pDni)
	{
		this.nombre=pNom;
		this.dni=pDni;
	}
	
	public String getNombre()
	{
		return this.nombre;
	}
	
}
