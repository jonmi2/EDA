package listasimetrica;


public class Main 
{

	public static void main(String[] args) 
	{
		MiDoubleLinkedList l = new MiDoubleLinkedList();
		SimpleLinkedList sim = new SimpleLinkedList();
		
		Node<Integer> n1 = new Node<Integer>(8);
		Node<Integer> n2 = new Node<Integer>(3);
		Node<Integer> n3 = new Node<Integer>(4);
		Node<Integer> n4 = new Node<Integer>(1);
		
		n1.next=n2;
		n2.next=n3;
		n3.next=n4;
		n4.next=null;
		sim.first=n1;
		
		System.out.println("la lista simple tiene q ser 8 3 4 1    y dice q es :    ");
		sim.imprimir();
		
		l.obtenerListaSimetrica(sim);
		
		System.out.println("ahora tiene q decir q la otra es -1 -4 -3 -8 8 3 4 1    y dice q es :    ");
		
		l.imprimir();
		
	}
	
}
