package listasimetrica;

public class MiDoubleLinkedList 
{
	public DoubleNode<Integer> first;
	
	public MiDoubleLinkedList()
	{
		this.first=null;
	}
	
	public void obtenerListaSimetrica(SimpleLinkedList l)
	{
		//pre:la lista contiene valores positivos distintos de 0
		//post: el resultado es la lista simetrica.
		Node<Integer> act = l.first;
		DoubleNode<Integer> l1 = new DoubleNode<Integer>(null);
		while (act.next!=null)
		{
			l1.data=act.data;
			l1.next= new DoubleNode<Integer>(null);
			l1.next.prev=l1;
			l1=l1.next;
			act=act.next;
		}
		l1.data=act.data;
		l1.next= new DoubleNode<Integer>(null);
		l1.next.prev=l1;
		l1=l1.next;		
		DoubleNode<Integer> pos = l1;
		while (pos.prev!=null)
		{
			pos=pos.prev;
		}
		Node<Integer> act2 = l.first;
		while (act2.next!=null)
		{
			pos.prev= new DoubleNode<Integer>(act2.data*-1);
			pos.prev.next=pos;
			pos=pos.prev;
			act2=act2.next;
		}
		l1.data=act2.data*-1;
		pos.prev=l1;
		l1.next=pos;
		this.first=l1;
	}
	
	public void imprimir()
	{
		System.out.println(first.data);
		DoubleNode<Integer> act = first.next;
		while (act!=first)
		{
			System.out.println(act.data);
			act=act.next;
		}
	}
	
}
