package listasimetrica;

public class SimpleLinkedList 
{
	//lista enlazada simple no circular
	public Node<Integer> first;
	
	public SimpleLinkedList()
	{
		this.first=null;
	}
	
	public void imprimir()
	{
		Node<Integer> act = first;
		
		while (act!=null)
		{
			System.out.println(act.data);
			act=act.next;
		}
		
	}
}
