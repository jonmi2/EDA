package reemplazarelemporsec;

public class DoubleLinkedList 
{
	public DoubleNode<String> first;
	
	public DoubleLinkedList() {this.first=null;}
	
	public void reemplazar(Pareja[] parejas)
	{
		//pre: parejas esta ordenado y al reemplazarlo seguir� ordenada
		//post: se han reemplazado los elementos de parejas a�adiendolos a la lista y la lista sigue ordenada
		
		if (this.first==null)
		{
			return;
		}
		else
		{
			int i = 0;
			DoubleNode<String> act = first;
			if (parejas[0]==null)
			{
				return;
			}
			else
			{
				while(i<parejas.length && act!=null)//act!=null ns si es as� o act.sig!=null
				{				
					if (act.data.compareTo(parejas[i].target)>0)
					{
						i++;
					}
					else if (act.data.compareTo(parejas[i].target)<0)
					{
						act=act.next;
					}
					else					
					{
							int pos=1;
							act.data=parejas[i].replacement[0];						
							while (pos<parejas[i].replacement.length) 
							{															
								DoubleNode<String> nuevo = new DoubleNode<String>(parejas[i].replacement[pos]);
								nuevo.next=act.next;
								nuevo.prev=act;
								act.next=nuevo;
								if (nuevo.next!=null) 
								{
									nuevo.next.prev=nuevo;
								}															
								act=nuevo;								
								pos++;
							}
							i++;
							act=act.next;
					}
				}
			}
		}
		
	}
	
	
	public void imprimir()
	{
		DoubleNode<String> act = first;
		while (act.next!=null)
		{
			System.out.println(act.data);
			act=act.next;
		}
		System.out.println(act.data);
	}
	
}
