package reemplazarelemporsec;

public class Main 
{
	public static void main(String[] args)
	{
		DoubleLinkedList l = new DoubleLinkedList();
		
		DoubleNode<String> n1 = new DoubleNode<String>("ama");
		DoubleNode<String> n2 = new DoubleNode<String>("col");
		DoubleNode<String> n3 = new DoubleNode<String>("mar");
		DoubleNode<String> n4 = new DoubleNode<String>("rio");
		DoubleNode<String> n5 = new DoubleNode<String>("zar");
		
		n1.next=n2;
		n2.prev=n1;
		n2.next=n3;
		n3.prev=n2;
		n3.next=n4;
		n4.prev=n3;
		n4.next=n5;
		n5.prev=n4;
		l.first=n1;
		
		
		
		Pareja p1 = new Pareja("col",3);
		Pareja p2 = new Pareja("mar",3);
		Pareja p3 = new Pareja("zar",2);
		
		p1.replacement[0]="cola";
		p1.replacement[1]="colar";
		p1.replacement[2]="color";
		
		p2.replacement[0]="mara";
		p2.replacement[1]="marte";
		p2.replacement[2]="marzo";
		
		p3.replacement[0]="zara";
		p3.replacement[1]="zarza";

		Pareja[] parejas = {p1,p2,p3};
		
		l.reemplazar(parejas);
		
		l.imprimir();
		
	}
}
