package reemplazarelemporsec;

public class Pareja 
{
	public String target;
	String[] replacement;//ordenada alfabeticamente y no vac�a
	
	public Pareja(String t, int num)
	{
		this.target=t;
		this.replacement= new String[num];
	}
}
