package sumamatrices;

public class Main 
{
	public static void main(String[] args)
	{
		Matriz m1 = new Matriz();
		Node mn1 = new Node(3,2,2);
		Node mn2 = new Node(5,2,4);
		Node mn3 = new Node(1,3,1);
		Node mn4 = new Node(2,4,4);
		mn1.next=mn2;
		mn2.next=mn3;
		mn3.next=mn4;
		m1.first=mn1;
		
		
		Matriz m2 = new Matriz();
		Node bn1 = new Node(9,1,1);
		Node bn2 = new Node(7,2,2);
		Node bn3 = new Node(2,3,3);
		Node bn4 = new Node(3,4,4);
		bn1.next=bn2;
		bn2.next=bn3;
		bn3.next=bn4;
		m2.first=bn1;
		
		
		Matriz mvac = new Matriz();
		
		
		Matriz rdo = new Matriz();
		rdo=rdo.sumar(m1, m2);
		rdo.imprimir();
		
	}
}
