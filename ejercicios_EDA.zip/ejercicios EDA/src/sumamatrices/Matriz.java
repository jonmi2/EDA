package sumamatrices;

public class Matriz 
{
	public Node first;
	
	public Matriz()
	{
		this.first=null;
	}
	
	public boolean isEmpty() {return this.first==null;}
	
	public Matriz sumar(Matriz m1, Matriz m2)
	{
		Matriz m = new Matriz();
		
		if (m1.isEmpty() && m2.isEmpty())
		{
			System.out.println("rdo es vacio ya q las dos son vacias");
			return m;
		}
		else if (m1.isEmpty())
		{
			return m2;
		}
		else if (m2.isEmpty())
		{
			return m1;
		}
		else
		{
			Node act1 = m1.first;
			Node act2 = m2.first;
			Node ult= new Node();
			while(act1!=null && act2!=null)
			{
				if (act1.fila<act2.fila || (act1.fila==act2.fila && act1.col<act2.col))
				{
					Node nou = new Node(act1.dato,act1.fila,act1.col);
					if (m.first==null)
					{
						m.first=nou;
						ult=nou;
					}
					else
					{
						ult.next=nou;
						ult=nou;
					}
					act1=act1.next;
				}
				else if (act1.fila>act2.fila || (act1.fila==act2.fila && act1.col>act2.col))//sin terminarr
				{
					Node nou = new Node(act2.dato,act2.fila,act2.col);
					if (m.first==null)
					{
						m.first=nou;
						ult=nou;
					}
					else
					{
						ult.next=nou;
						ult=nou;
					}
					act2=act2.next;
				}
				else//misma fila y misma col
				{
					
				}	
			}		
			while(act1!=null)
			{
				Node nou = new Node(act1.dato,act1.fila,act1.col);
				if (m1.first==null)
				{
					m.first=nou;
					ult=nou;
				}
				else
				{
					ult.next=nou;
					ult=nou;
				}
				act1=act1.next;
			}
			while(act2!=null)
			{
				Node nou = new Node(act2.dato,act2.fila,act2.col);
				if (m2.first==null)
				{
					m.first=nou;
					ult=nou;
				}
				else
				{
					ult.next=nou;
					ult=nou;
				}
				act2=act2.next;
			}
		}
		
		
		return m;
	}
	
	
	
	public void imprimir()
	{
		if (this.first==null)
		{
			System.out.println("rdo = MATRIZ VAC�A");
		}
		else
		{
			Node act = this.first;
			while (act.next!=null)
			{
				System.out.println("["+act.dato+"] ["+act.fila+"] ["+act.col+"]");
				act=act.next;
			}
			System.out.println("["+act.dato+"] ["+act.fila+"] ["+act.col+"]");
		}
	}
	
}
