package sumamatrices;

public class Node 
{
	public int dato;
	public int fila;
	public int col;
	public Node next;
	
	public Node(int pdato, int pfila, int pcol)
	{
		this.dato=pdato;
		this.fila=pfila;
		this.col=pcol;
		this.next=null;
	}
	
	public Node()
	{
		this.dato=0;
		this.fila=0;
		this.col=0;
		this.next=null;
	}
	
}
