import java.util.ArrayList;
import java.util.Iterator;


public class ListaActores 
{

	private ArrayList<Actor> lista;
	
	
	public ListaActores()
	{
		this.lista=new ArrayList<Actor>();
	}
	
	private Iterator<Actor> getIterador()
	{
		return lista.iterator();
	}
	
	public boolean esta(String pActor)
	{
		Iterator<Actor> itr = this.getIterador();
		boolean enc = false;
		Actor a = null;
		while (enc==false && itr.hasNext())
		{
			a=itr.next();
			if(a.getNombre().equals(pActor))
			{
				enc=true;
			}
			else
			{
				enc=false;
			}
		}
		return enc;
	}
	
	
	public void anadir(Actor pActor)
	{
		if (this.esta(pActor.getNombre())==false)
		{
		this.lista.add(pActor);
		}		
	}
	
	public void imprimir()
	{	
		Iterator<Actor> itr = this.getIterador();
		Actor a = null;
		System.out.println("Hay un total de " +this.lista.size()+ " actores");
		while (itr.hasNext())
		{
			a = itr.next();
			System.out.println(a.getNombre());
		}
	}
	

	
	public void anadirpeliaact(String pNom, Pelicula pPeli)
	{
		Iterator<Actor> itr = this.getIterador();
		boolean enc = false;
		Actor a = null;
		while (enc==false && itr.hasNext())
		{
			a=itr.next();
			if(a.getNombre().equals(pNom))
			{
				enc=true;
			}			
		}
		if (enc==true)
		{
			a.anadirpeliaact(pPeli);
		}
	}
		
	
	
}
