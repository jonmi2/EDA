import java.util.Scanner;

public class Menu 
{
	private static Menu miMenu = new Menu();
	
	private Menu() {}
	
	public static Menu getMenu() 
	{
		return miMenu;
	}
	
	public void showMenu()
	{
		datos miDatos = datos.getDatos();          
		HashMapAc MapAc = HashMapAc.getMiMapa();
		HashMapPeli MapPe = HashMapPeli.getMiMapa();
        Scanner sn=new Scanner(System.in);
        boolean exit=false;
        int opcion; 
        while(!exit)
        {
        	System.out.println("\n----------------------------------------------------------------------------------------------------------------");
            System.out.println("\t\t Menu Principal \n");
            System.out.println("Seleccione una de las siguientes opciones:\n");
            System.out.println("0. Cargar los datos del fichero");
            System.out.println("1. Buscar actor/actriz en el fichero");
            System.out.println("2. Insertar un nuevo actor/actriz");               
            System.out.println("3. Eliminar un actor/actriz");
            System.out.println("4. Cambiar el a�o de una peli");
            System.out.println("5. Devolver las peliculas de un actor");
            System.out.println("6. Devolver los actores de una pelicula");
            System.out.println("7. Guardar la lista en un fichero");
            System.out.println("8. Obtener una lista de actores ordenada por nombre y apellido");
            System.out.println("9. Finalizar Programa");
            System.out.print("TU ELECCI�N---> ");
            opcion=sn.nextInt();

            switch (opcion)
            {
            	case 0:            		
       			 	System.out.println("Vamos a cargar los datos.");
            		miDatos.cargarLista();
            		break;
                case 1:
                	Scanner sc2 = new Scanner(System.in);               	
            		System.out.println("Vamos a buscar un actor.");
            		System.out.println("Ingresa un nombre: ");                   
                    String nAct1 = sc2.nextLine();
                	MapAc.buscarAct(nAct1);                   
                    break;
                case 2:
                	Scanner sc3 = new Scanner(System.in);
                    System.out.println("Vamos a a�adir un nuevo actor");
                    System.out.println("Ingresa un nombre: ");
                    String nAct2 = sc3.nextLine();
                    Actor a1 = new Actor(nAct2);
                    
                    if (MapAc.esta(a1))
                    {
                    	System.out.println("No se va a a�adir el actor ya que ya hay uno que se llama igual en nuestros datos");
                    }
                    else
                    {
                    	MapAc.anadir(a1);
                    	System.out.println("El actor "+ nAct2 +" se ha a�adido a la lista.");
                    	
                    }
                    break;
                case 3:
                	Scanner sc4 = new Scanner(System.in);           		
            		System.out.println("Vamos a borrar un actor");
            		System.out.println("Ingresa un actor:");                    
                    String nAct3 = sc4.nextLine();                    
                    
                    if (!MapAc.esta(nAct3))
                    {
                    	System.out.println("No se va a borrar el actor ya que no est� en nuestros datos");
                    }
                    else
                    {
                    	
                    	MapAc.borrarActor(nAct3);
                    	System.out.println("El actor "+ nAct3 +" se ha borrado de la lista");
                    	
                    }                  
                    break;                
                case 4:
                	Scanner sc5 = new Scanner(System.in);           		
            		System.out.println("Vamos a cambiar el a�o de una peli");
            		System.out.println("Ingresa una peli:");
                    String nPeli = sc5.nextLine();                                    
                    
                    if (!MapPe.esta(nPeli))
                    {
                    	System.out.println("No se puede modificar el a�o de una peli que no est�.");
                    }
                    else
                    {
                    	System.out.println("Ingresa el a�o del que ahora quieres que sea la peli:");
                        int ano = sc5.nextInt();
                    	Pelicula peli = MapPe.getP(nPeli);
                    	if (peli.getAno()==ano)
                		{
                			System.out.println("No se va a modificar el a�o ya que el a�o que has introducido es el mismo que el de la peli");
                		}
                		else
                		{
              			
                        	MapPe.modificarA�oPeli(nPeli, ano);
                        	System.out.println("El a�o de la peli "+nPeli+" ahora es: "+ano);
                        	
                		}
                    }                  
                	break;
                case 5:
                	Scanner sc6 = new Scanner(System.in);           		
            		System.out.println("Vamos a devolver las peliculas de un actor");
            		System.out.println("Ingresa un actor:");           		
                    String nAct = sc6.nextLine();  
                	MapAc.devolverPelisAct(nAct);
                	break;
                case 6:
                	Scanner sc7 = new Scanner(System.in);           		
            		System.out.println("Vamos a devolver los actores de una peli");
            		System.out.println("Ingresa una peli:");           		
                    String nPelic = sc7.nextLine();  
                	MapPe.devolverActsPeli(nPelic);
                	break;
                case 7:
                	Scanner sc8 = new Scanner(System.in);           		
            		System.out.println("Ingresa la ruta del directorio destino del fichhero");		          		
                    String ruta = sc8.nextLine(); 
                    System.out.println("Ingresa el nombre para el fichero:");
                    String nFi = sc8.nextLine();
                    MapAc.crearFichero(nFi,ruta);
                	break;
                case 8:
                	System.out.println("Ahora vamos a ordenar la lista por nombres y apellidos");
                	MapAc.listaOrdenada();
                	break;
                case 9:
                	System.out.println("Se cierra el programa");
                	exit=true;
                    break;
                default:
                	System.out.println("Solo numeros del 0 al 9\n");
                }
            
            }
        sn.close();
	}
}
