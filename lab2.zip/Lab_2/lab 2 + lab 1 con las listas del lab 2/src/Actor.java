public class Actor  implements Comparable<Actor>
{
	private String nombre;
	private ListaPelis lista;
	
	
	public Actor(String pNombre) {
		this.nombre = pNombre;
		this.lista = new ListaPelis();
	}
	
	
	public String getNombre()
	{
		return this.nombre;
	}
	
	public void anadirpeliaact(Pelicula pPeli)
	{
		this.lista.anadir(pPeli);
	}
	
	public void imprlispelisdeact()
	{
		this.lista.imprimir();
	}


	public int compareTo(Actor o) 
	{
		return this.nombre.compareTo(o.getNombre());
	}
	
}
