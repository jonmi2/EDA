import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;


public class HashMapAc 
{
	
    private HashMap<String,Actor> mapa;//String=key y Actor=Value
    private static HashMapAc miMapa = null;

   
    private HashMapAc()
    {
        mapa=new HashMap<String,Actor>();
    }

   

    
    public static HashMapAc getMiMapa()
    {
        if(miMapa==null)
        {
            miMapa=new HashMapAc();
        }
        return miMapa;
    }
    
    public boolean esta(Actor a)
    {
    	if (this.mapa.containsKey(a.getNombre()))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    public void anadir(Actor a)
    {
    	if (esta(a)==false)
    	{
    		this.mapa.put(a.getNombre(), a);
    	}
    }
    
    public void anadirpeliaact(Pelicula p, Actor a)
    {
    	this.mapa.get(a.getNombre()).anadirpeliaact(p);
    }
    
    public void imprActs()
    {
    	System.out.println("Hay un total de "+ this.mapa.size() +" actores");
    	for (String nombreActor : mapa.keySet()) 
    	{
            System.out.println(nombreActor);
        }
    }
    
    public boolean esta(String nAct)
    {
    	if (this.mapa.containsKey(nAct))
    	{
    		return true;
    	}
    	else 
    	{
    		return false;
    	}
    }
    
    public void buscarAct(String nAct)
    {
    	if (this.esta(nAct))
    	{
    		System.out.println("El actor est� en la lista y se llama " + nAct);
    	}
    	else
    	{
    		System.out.println("El actor no est� en nuestros datos");
    	}
    }
    
    public void borrarActor (String nAct)
    {
    	if (this.esta(nAct))
    	{
    		this.mapa.remove(nAct);
    	}
    }
    
    public void devolverPelisAct(String nActor)
    {
    	if (!this.esta(nActor))
    	{
    		System.out.println("El actor no est� en nuestros datos.");
    	}
    	else
    	{
    		Actor act = this.mapa.get(nActor);
    		act.imprlispelisdeact();
    	}
    }
    
    public void crearFichero(String nombre, String ruta) 
    {
    	String nombreArchivo = ruta+"/"+nombre+".txt";	
    	try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
    		writer.write("**Lista de actores**");
    		writer.newLine();
    		writer.newLine();
    		for (String actor : mapa.keySet()) {
                writer.write(actor);
                writer.newLine(); 
            }
            System.out.println("Los actores se han guardado en el archivo: " + nombreArchivo);
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }
    }
    
    public void listaOrdenada() 
    {
    	ListaActores lista= new ListaActores();
    	List<String> nombres = new ArrayList<>(mapa.keySet());
    	Collections.sort(nombres);
    	for (String nombre : nombres) {
    		lista.anadir(mapa.get(nombre));
    	}
    	lista.imprimir();
    }
    
    
}
