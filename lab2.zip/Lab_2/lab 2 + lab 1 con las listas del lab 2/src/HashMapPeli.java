import java.util.HashMap;

public class HashMapPeli 
{


    private HashMap<String,Pelicula> mapa;//String=key y Pelicula=Value
    private static HashMapPeli miMapa = null;

   
    private HashMapPeli()
    {
        mapa=new HashMap<String,Pelicula>();
    }

   

    
    public static HashMapPeli getMiMapa()
    {
        if(miMapa==null)
        {
            miMapa=new HashMapPeli();
        }
        return miMapa;
    }
    
    public boolean esta(Pelicula p)
    {
    	if (this.mapa.containsKey(p.getNombre()))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    public void anadir(Pelicula p)
    {
    	if (esta(p)==false)
    	{
    		this.mapa.put(p.getNombre(), p);
    	}
    }
    
    public boolean esta(String nPeli)
    {
    	if (this.mapa.containsKey(nPeli))
    	{
    		return true;
    	}
    	else 
    	{
    		return false;
    	}
    }
    
    public Pelicula getP(String nPeli)
    {
    	return this.mapa.get(nPeli);
    }
    
    public void anadiractapeli(Actor a,Pelicula p)
    {
    	this.mapa.get(p.getNombre()).anadiractapeli(a);
    }
    
    public void modificarA�oPeli(String nPeli, int ano)
    {
    	if (this.esta(nPeli))
    	{
    		Pelicula peli = this.mapa.get(nPeli);
    		if (peli.getAno()==ano)
    		{
    			System.out.println("No se va a modificar el a�o ya que el a�o que has introducido es el mismo que el de la peli");
    		}
    		else
    		{
    			Pelicula peliNou = new Pelicula(nPeli, ano);
    			this.mapa.replace(nPeli, peliNou);
    		}
    	}
    }
    
    public void imprPelis()
    {
    	System.out.println("Hay un total de "+ this.mapa.size() +" peliculas");
    	for (String nombrePeli : mapa.keySet()) 
    	{
            System.out.println(nombrePeli + " / a�o: " + this.mapa.get(nombrePeli).getAno());
        }
    }
    
    public void devolverActsPeli(String nPeli)
    {
    	if (!this.esta(nPeli))
    	{
    		System.out.println("La peli no est� en nuestros datos.");
    	}
    	else
    	{
    		Pelicula peli = this.mapa.get(nPeli);
    		peli.imprActs();
    	}
    }
}
