

public class OrderedDoubleLinkedList<T extends Comparable<T>> extends DoubleLinkedList<T> implements OrderedListADT<T> {
	
	public void add(T elem){
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		Node<T> act = first;
		Node<T> nuevo = new Node<>(elem);
		boolean enc = false;
		
			if (this.isEmpty()) { //si la lista est� vacia
				nuevo.next = nuevo;
				nuevo.prev = nuevo;
				first = nuevo;
				enc = true;
				count++;
				return;
			}
		while (!enc) {
		 if ((act.data.compareTo(elem)<=0) && (act.next.data == first.data)) { //si es mayor o igual que el actual pero esta al final de la lista
				nuevo.prev = act;
				nuevo.next = act.next;
				act.next.prev = nuevo;
				act.next = nuevo;
				enc = true;
				count++;
			}
			else if (act.data.compareTo(elem)<=0) { //si es mayor o igual que el actual
				act = act.next;				
			}
			else
			{
				act.prev.next=nuevo;
				nuevo.prev=act.prev;
				act.prev=nuevo;
				nuevo.next=act;
				enc=true;
				if (act==first) {first=nuevo;}
				count++;
			}
		}
	}
	
	public void merge(OrderedDoubleLinkedList<T> lista){//PONIA DoubleLinkedList PREGUNTAR
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		
		this.count=this.count+lista.count;
			if (lista.isEmpty() || (lista.isEmpty()&&this.isEmpty())) 
			{	
				
			}
			else if (this.isEmpty()) 
			{
				this.first = lista.first;
				
			}
			else
			{			
				Node<T> act = first;
				Node<T> actLista = lista.first;
							
				while(!(actLista.next.equals(lista.first)))// || !(act.next.equals(this.first))
				{
					if (act.data.compareTo(actLista.data)<=0)//act<=actLista
					{
						while(act.next.data.compareTo(actLista.data)<0 && !(act.next.equals(this.first)))//act.next<actLista
						{
							act=act.next;
						}
						
						Node<T> nou = new Node<T>(actLista.data);
						nou.prev=act;
						nou.next=act.next;
						act=act.next;
						act.prev.next=nou;
						act.prev=nou;
						actLista=actLista.next;
						act=act.prev;
					}
					else if (act.data.compareTo(actLista.data)>0 && act.equals(this.first))//act>actLista y act es el primero
					{
						Node<T> nou = new Node<T>(actLista.data);
						nou.next=act;
						nou.prev=act.prev;
						act.prev.next=nou;
						act.prev=nou;
						actLista=actLista.next;
						this.first=nou;
					}
					else if (act.data.compareTo(actLista.data)>0)//act>actLista
					{
						Node<T> nou = new Node<T>(actLista.data);
						nou.prev=act.prev;
						nou.prev.next=nou;
						act.prev=nou;
						nou.next=act;
						actLista=actLista.next;
					}
				}
				if (act.data.compareTo(actLista.data)<=0)//act<=actLista
				{
					while(act.next.data.compareTo(actLista.data)<0 && !(act.next.equals(this.first)))//act.next<actLista
					{
						act=act.next;
					}
					
					Node<T> nou = new Node<T>(actLista.data);
					nou.prev=act;
					nou.next=act.next;
					act=act.next;
					act.prev.next=nou;
					act.prev=nou;
					actLista=actLista.next;
					act=act.prev;
				}
				else if (act.data.compareTo(actLista.data)>0 && act.equals(this.first))//act>actLista y act es el primero
				{
					Node<T> nou = new Node<T>(actLista.data);
					nou.next=act;
					nou.prev=act.prev;
					act.prev.next=nou;
					act.prev=nou;
					actLista=actLista.next;
					this.first=nou;
				}
				else if (act.data.compareTo(actLista.data)>0)//act>actLista
				{
					Node<T> nou = new Node<T>(actLista.data);
					nou.prev=act.prev;
					nou.prev.next=nou;
					act.prev=nou;
					nou.next=act;
					actLista=actLista.next;
				}
			}
	}
	

}