
public class Pelicula implements Comparable<Pelicula>
{
	private int ano;
	private String nombre;
	private ListaActores lista;
	
	
	public Pelicula(String pNombre, int pAno) {
		this.ano=pAno;
		this.nombre = pNombre;
		this.lista = new ListaActores();
	}
	
	public String getNombre()
	{
		return this.nombre;
	}
	
	public int getAno()
	{
		return this.ano;
	}
	
	public void anadiractapeli(Actor pActor)
	{
		this.lista.anadir(pActor);
	}
	
	
	public void imprActs()
	{
		this.lista.imprimir();
	}

	public int compareTo(Pelicula o) {
		return this.nombre.compareTo(o.getNombre());
	}
}
