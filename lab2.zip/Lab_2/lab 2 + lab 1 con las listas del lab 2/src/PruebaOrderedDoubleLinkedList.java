
public class PruebaOrderedDoubleLinkedList {	
		
		public static void main(String[] args)  {
			
			OrderedDoubleLinkedList<Integer> l = new OrderedDoubleLinkedList<Integer>();
			
			System.out.print("Lista vac�a, no deber�a imprimir nada y n�mero de elementos=0.");
			System.out.print(" ");
			l.visualizarNodos();
			System.out.print(" ");
			System.out.print(" Num elementos: " + l.size());
			System.out.println(" ");
			
			l.add(1);
			l.add(3);
			l.add(6);
			l.add(7);
			l.add(9);
			l.add(0);
			l.add(20);
			l.remove(7);

			System.out.println(" ");
			System.out.print(" Lista con elementos. Deber�a imprimir (0,1,3,6,9,20) y n�mero de elementos 6");
			System.out.println("");
			l.visualizarNodos();
			System.out.println(" Num elementos: " + l.size());
					
			System.out.println("");
			System.out.println("Prueba Find. En el 20, 0 y 9 deber�a devolver ese  n�mero. En el 7 tiene que devolver null.");
			System.out.println("20? " + l.find(20));
			System.out.println("9? " + l.find(9));
			System.out.println("0? " + l.find(0));
			System.out.println("7? " + l.find(7));
			
			
			System.out.println("");
			OrderedDoubleLinkedList<Persona> l2 = new OrderedDoubleLinkedList<Persona>();		
			l2.add(new Persona("jon", "1111"));
			l2.add(new Persona("ana", "7777"));			
			l2.add(new Persona("amaia", "3333"));
			l2.add(new Persona("unai", "8888"));
			l2.add(new Persona("pedro", "2222"));
			l2.add(new Persona("olatz", "5555"));

			l2.remove(new Persona("", "8888"));
		
			

			
			System.out.print(" Lista con personas. Deber�a imprimir ([amaia 3333],[ana 7777],[jon 1111],[olatz 5555],[pedro 2222]) y n�mero de elementos=5");
			System.out.println(" ");
			l2.visualizarNodos();
			System.out.println(" Num elementos: " + l2.size());
					
			System.out.println("");
			System.out.println("Prueba Find. Con 1111, 2222, 5555 y 7777 deber�a devolver ese n�mero. Con el 8888 deber�a devolver null.");
			System.out.print(" ");
			System.out.println("1111? " + l2.find(new Persona("", "1111")));
			System.out.println("2222? " + l2.find(new Persona("", "2222")));
			System.out.println("5555? " + l2.find(new Persona("", "5555")));
			System.out.println("7777? " + l2.find(new Persona("", "7777")));	
			System.out.println("8888? " + l2.find(new Persona("", "8888")));	
			
			
			//PRUEBA MERGE
			System.out.println("");
			System.out.println("...............");
			System.out.println("Prueba Merge ...............");
			OrderedDoubleLinkedList<Integer> principal = new OrderedDoubleLinkedList<Integer>();
			OrderedDoubleLinkedList<Integer> nue = new OrderedDoubleLinkedList<Integer>();
			
			System.out.println("Dos listas vacias. Deber�a decir que el tama�o es 0 y no imprimir nada.");
			
			System.out.println(" ");
			System.out.println("lista principal");
			principal.visualizarNodos();
			System.out.println(" Num elementos: " + principal.size());
			
			System.out.println(" ");
			System.out.println("lista secundaria");
			nue.visualizarNodos();
			System.out.println(" Num elementos: " + nue.size());
			
			System.out.println("");
			System.out.println("prueba merge");
			principal.merge(nue);
			principal.visualizarNodos();
			System.out.println(" Num elementos: " + principal.size());
			
			
			principal.add(1);
			principal.add(90);
			principal.add(3);
			principal.add(4);
			principal.add(65);
			principal.add(21);
			
			
			System.out.println(" ");
			System.out.println("Lista secundaria vacia. Deber�a decir que el tama�o es 6 e imprimir (1,3,4,21,65,90).");
			
			System.out.println(" ");
			System.out.println("lista principal");
			principal.visualizarNodos();
			System.out.println(" Num elementos: " + principal.size());
			
			System.out.println(" ");
			System.out.println("lista secundaria");		
			nue.visualizarNodos();
			System.out.println(" Num elementos: " + nue.size());
			
			System.out.println("");
			System.out.println("prueba merge");
			principal.merge(nue);
			principal.visualizarNodos();
			System.out.println(" Num elementos: " + principal.size());
			
			//
			

			nue.add(1);
			nue.add(-3);
			nue.add(4);
			nue.add(2334);
			nue.add(5);
			nue.add(5);
			nue.add(3);
			nue.add(100);
			
			
			OrderedDoubleLinkedList<Integer> ppal = new OrderedDoubleLinkedList<Integer>();
			
			
			System.out.println(" ");
			System.out.println("Lista principal vac�a y secundaria con elementos. Deber�a decir que el tama�o es 8 e imprimir (-3,1,3,4,5,5,100,2334).");
			
			System.out.println("");
			System.out.println("lista principal");
			ppal.visualizarNodos();
			System.out.println(" Num elementos: " + ppal.size());
			
			System.out.println(" ");
			System.out.println("lista secundaria");
			System.out.println("");
			nue.visualizarNodos();
			System.out.println(" Num elementos: " + nue.size());
			
			System.out.println("");
			System.out.println("prueba merge");
			ppal.merge(nue);
			ppal.visualizarNodos();
			System.out.println(" Num elementos: " + ppal.size());
			
			
			
			
			OrderedDoubleLinkedList<Integer> nou = new OrderedDoubleLinkedList<Integer>();
			OrderedDoubleLinkedList<Integer> prin = new OrderedDoubleLinkedList<Integer>();
			
			prin.add(1);
			prin.add(90);
			prin.add(3);
			prin.add(4);
			prin.add(65);
			prin.add(21);
			
			nou.add(1);
			nou.add(-3);
			nou.add(4);
			nou.add(2334);
			nou.add(5);
			nou.add(5);
			nou.add(3);
			nou.add(100);
			
			System.out.println(" ");
			System.out.println("2 listas con elementos. Deber�a decir que el tama�o es 14 e imprimir (-3,1,1,3,3,4,4,5,5,21,65,90,100,2334).");
			
			System.out.println("");
			System.out.println("lista principal");
			prin.visualizarNodos();
			System.out.println(" Num elementos: " + prin.size());
			
			System.out.println("lista secundaria");
			System.out.println("");
			nou.visualizarNodos();
			System.out.println(" Num elementos: " + nou.size());
			
			System.out.println("");
			System.out.println("prueba merge");
			prin.merge(nou);
			prin.visualizarNodos();
			System.out.println(" Num elementos: " + prin.size());
			
			
			
			
	}
	}

