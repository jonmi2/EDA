package Pruebas;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import segundaFase.UnorderedDoubleLinkedList;

class TestDoubleLinkedList {

	UnorderedDoubleLinkedList<Integer> l = new UnorderedDoubleLinkedList<Integer>();
	
	@BeforeEach
	void setUp() throws Exception {
		l = new UnorderedDoubleLinkedList<Integer>();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testSetDescr() {
		l.setDescr("Descricion de prueba");
		assertEquals("Descricion de prueba", l.getDescr());
	}


	@Test
	void testRemoveFirst() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToFront(8);
		l.removeFirst();
		assertFalse(l.contains(8));
	}

	@Test
	void testRemoveLast() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToFront(8);
		l.removeLast();
		assertFalse(l.contains(6));
	}

	@Test
	void testRemove() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToFront(8);
		l.remove(3);
		assertFalse(l.contains(3));
	}

	@Test
	void testFirst() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToFront(9);
		l.addToFront(8);
		assertEquals(8, l.first());
	}

	@Test
	void testLast() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToFront(9);
		l.addToFront(8);
		assertEquals(6, l.last());
	}

	@Test
	void testContains() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToFront(8);
		assertTrue(l.contains(3));
		assertFalse(l.contains(4));
	}

	@Test
	void testFind() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToFront(8);
		assertEquals(6, l.find(6));
		assertEquals(null, l.find(12));
	}

	@Test
	void testIsEmpty() {
		assertTrue(l.isEmpty());
		l.addToFront(2);
		assertFalse(l.isEmpty());
	}

	@Test
	void testSize() {
		l.addToRear(1);
		l.addToRear(3);
		l.addToRear(6);
		l.addToRear(7);
		l.addToRear(9);
		l.addToRear(0);
		l.addToRear(20);
		l.addToFront(8);
		assertEquals(8, l.size());
	}

}
