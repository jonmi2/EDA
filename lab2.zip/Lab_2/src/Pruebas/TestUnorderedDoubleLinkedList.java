package Pruebas;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import segundaFase.UnorderedDoubleLinkedList;

class TestUnorderedDoubleLinkedList {

	UnorderedDoubleLinkedList<Integer> l = new UnorderedDoubleLinkedList<Integer>();
	
	@BeforeEach
	void setUp() throws Exception {
		l = new UnorderedDoubleLinkedList<Integer>();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testAddToFront() {
		l.addToFront(3);
		l.addToFront(2);
		l.addToFront(1);
		assertEquals("DoubleLinkedList [1] \n[2] \n[3] \n]", l.toString()); //CON VARIOS ELEMENTOS
		assertEquals(3, l.size());
		
		l = new UnorderedDoubleLinkedList<Integer>();
		l.addToFront(1);
		assertEquals("DoubleLinkedList [1] \n]", l.toString()); //CON UN SOLO ELEMENTO
		assertEquals(1, l.size());
	}

	@Test
	void testAddToRear() {
		l.addToRear(1);
		l.addToRear(2);
		l.addToRear(3);
		assertEquals("DoubleLinkedList [1] \n[2] \n[3] \n]", l.toString()); //CON VARIOS ELEMENTOS
		assertEquals(3, l.size());
		
		l = new UnorderedDoubleLinkedList<Integer>();
		l.addToRear(1);
		assertEquals("DoubleLinkedList [1] \n]", l.toString()); //CON UN SOLO ELEMENTO
		assertEquals(1, l.size());
	}

	@Test
	void testAddAfter() {
		l.addToRear(1);
		l.addToRear(3);
		l.addAfter(2, 1);
		assertEquals("DoubleLinkedList [1] \n[2] \n[3] \n]", l.toString()); //CON VARIOS ELEMENTOS
		assertEquals(3, l.size());
		
		l = new UnorderedDoubleLinkedList<Integer>();
		l.addToRear(1);
		assertEquals("DoubleLinkedList [1] \n]", l.toString()); //CON UN SOLO ELEMENTO
		assertEquals(1, l.size());
	}

}
