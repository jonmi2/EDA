package segundaFase;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class DoubleLinkedList<T extends Comparable<T>> implements ListADT<T> {

	// Atributos
	protected Node<T> first;  // apuntador al PRIMERO
	protected String descr;  // descripci�n
	protected int count;

	// Constructor
	public DoubleLinkedList() {
        first = null;
		descr = "";
		count = 0;
	}
	
	public void setDescr(String nom) {
	  descr = nom;
	}

	public String getDescr() {
	  return descr;
	}

	public T removeFirst() {
	// Elimina el primer elemento de la lista
        // Precondici�n: 
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		if (this.isEmpty())
		{
			return null;
		}
		else
		{
			T borrado = first.data;
			first.prev.next = first.next;
			first.next.prev = first.prev;
			first = first.next;
			count--;
			return borrado;
		}
	}

	public T removeLast() {
	// Elimina el �ltimo elemento de la lista
        // Precondici�n: 
			// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		T borrado = first.prev.data;
		first.prev.prev.next = first;
		first.prev = first.prev.prev;
		count--;
		return borrado;
		   }


	public T remove(T elem) {
	//Elimina un elemento concreto de la lista
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		Node<T> act = first.next;
		boolean vuelta = false;
		boolean enc = false;
		while (!enc && !vuelta) 
		{
			if (first.data.equals(elem))
			{
				return this.removeFirst();
			}		
			else if (act.data.equals(elem))
			{
				enc = true;
				act.prev.next = act.next;
				act.next.prev = act.prev;
				count--;
				return elem;
			}
			else 
			{
				if (act.next.equals(first)) 
				{
					vuelta = true;
					return null;
				}
				else 
				{
					act = act.next;
				}
			}
		}
		return null;
	}

	public T first() {
	//Da acceso al primer elemento de la lista
	      if (isEmpty())
	          return null;
	      else return first.data;
	}

	public T last() {
	//Da acceso al �ltimo elemento de la lista
	      if (isEmpty())
	          return null;
	      else return first.prev.data;
	}

	public boolean contains(T elem) {
	//Determina si la lista contiene un elemento concreto
		      if (isEmpty())
		          return false;
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		      	Node<T> act = first;
				boolean vuelta = false;
				boolean enc = false;
				while (!enc && !vuelta) 
				{
					if (act.data.equals(elem)) 
					{
						enc = true;
					}
					else {
						if (act.next.equals(first)) {
							vuelta = true;
							return false;
						}
						else {
							act = act.next;
						}
					}
				}
				return enc;
		   }

	public T find(T elem) {
	//Determina si la lista contiene un elemento concreto, y develve su referencia, null en caso de que no est�
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		if (contains(elem)) 
		{		
			return elem;         //Preguntar si esta bien o devuelve el numero del elemento
		}
		else {
			return null;
		}
	}

	public boolean isEmpty() 
	//Determina si la lista est� vac�a
	{ return first == null;};
	
	public int size() 
	//Determina el n�mero de elementos de la lista
	{ return count;};
	
	/** Return an iterator to the stack that iterates through the items . */ 
	public Iterator<T> iterator() { return new ListIterator(); } //ok

	   // an iterator, doesn't implement remove() since it's optional 
	   private class ListIterator implements Iterator<T> { //ok

		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		   private Node<T> act;
		   
		   public  ListIterator() 
		   {
			   this.act = first;
		   }
		   
		   
		   @Override
		   public boolean hasNext() 
		   {
			   return !act.next.equals(first);
		   }

		   
		   boolean primeraVez = true;  //si no el iterador no tiene en cuenta el primer elemento
			@Override
			public T next() 
			{
				if (primeraVez) {
					primeraVez = false;
					return act.data;
				}
				else if (hasNext()) 
				{
					act=act.next;
					return act.data;
				}
				else 
				{
					 throw new NoSuchElementException();
				}
			}


	   } 

		
         public void visualizarNodos() {
			System.out.println(this.toString());
		}

		@Override
		public String toString() {
			String result = new String();
			Iterator<T> it = iterator();
			boolean unElem = !this.isEmpty() && !it.hasNext(); //por si hay un solo elemnto en la lista que tambien lo imprima
			while (it.hasNext() || unElem) {
				T elem = it.next();
				result = result + "[" + elem.toString() + "] \n";
				if (unElem) {
					unElem = false;
				}
			}	
			return "DoubleLinkedList " + result + "]";
		}

}
