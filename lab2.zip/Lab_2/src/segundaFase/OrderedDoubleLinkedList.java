package segundaFase;

public class OrderedDoubleLinkedList<T extends Comparable<T>> extends DoubleLinkedList<T> implements OrderedListADT<T> {
	
	public void add(T elem){
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		Node<T> act = first;
		Node<T> nuevo = new Node<>(elem);
		boolean enc = false;
		while (!enc) {
			if (this.isEmpty()) { //si la lista est� vacia
				nuevo.next = nuevo;
				nuevo.prev = nuevo;
				first = nuevo;
				enc = true;
			}
			else if ((act.data.compareTo(elem)<=0) && (act.next.data == first.data)) { //si es mayor o igual que el actual pero esta al final de la lista
				nuevo.prev = act;
				nuevo.next = act.next;
				act.next.prev = nuevo;
				act.next = nuevo;
				enc = true;
			}
			else if (act.data.compareTo(elem)<=0) { //si es mayor o igual que el actual
				act = act.next;
			}
			else if (elem.compareTo(first.data)<0) { //si es menor que el primero
				first.prev.next = nuevo;
				first.prev = nuevo;
				nuevo.next = first;
				nuevo.prev = first.prev;
				first = nuevo;
				enc = true;
			}
			else if (act.data.compareTo(elem)>0) {  //si es menor que el actual
				act.prev.next = nuevo;
				nuevo.prev = act.prev;
				act.prev = nuevo;
				nuevo.next = act;
				enc = true;
			}
		}
	}

	public void merge(OrderedDoubleLinkedList<T> lista){ //PONIA DoubleLinkedList PREGUNTAR
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		Node<T> act = first;
		Node<T> actLista = lista.first;
		Node<T> actListaSig = lista.first.next;
		boolean fin = false;
		while (!fin) {
			if (lista.isEmpty() || (lista.isEmpty()&&this.isEmpty())) {	
				fin = true;
			}
			else if (this.isEmpty()) {
				this.first = lista.first;
				fin = true;
			}
			else if ((actLista.data.compareTo(act.data) >= 0) && act.next.data == first.data) { //a�ade al final
				act.next.prev = actLista;
				actLista.next = act.next;
				act.next = actLista;
				actLista.prev = act;
				actLista = actListaSig;
				actListaSig = actListaSig.next;
			}
			else if ((actLista.data.compareTo(act.data) > 0) && act.data == first.data) { //a�ade al principio
				first.prev.next = actLista;
				actLista.prev = first.prev;
				actLista.next = first;
				first.prev = actLista;
				first = actLista;
				actLista = actListaSig;
				actListaSig = actListaSig.next;
			}
			else if (actLista.data.compareTo(act.data) >= 0) {
				act = act.next;
			}
			else if (actLista.data.compareTo(act.data) >= 0) {
				act.prev.next = actLista;
				actLista.prev = act.prev;
				act.prev = actLista;
				actLista.next = act;
				actLista = actListaSig;
				actListaSig = actListaSig.next;
			}
			
			if (actLista.data == lista.first.data) {
				fin = true;
			}
			else {}
		}
	}


}
