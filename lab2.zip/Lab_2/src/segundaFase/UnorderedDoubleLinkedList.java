package segundaFase;

import java.util.NoSuchElementException;

public class UnorderedDoubleLinkedList<T extends Comparable<T>> extends DoubleLinkedList<T> implements UnorderedListADT<T> {
	
	public void addToFront(T elem) {
	// a�ade un elemento al comienzo
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		Node<T> nuevo = new Node<T>(elem);
		if (this.isEmpty())
		{
			nuevo.next = nuevo;
			nuevo.prev = nuevo;
			first=nuevo;
		}
		else
		{		
			nuevo.prev=first.prev;
			nuevo.next=first;
			first.prev.next=nuevo;
			first.prev=nuevo;
			first=nuevo;
		}
		count++;
	}

	public void addToRear(T elem) {
	// a�ade un elemento al final 
		// COMPLETAR EL CODIGO Y CALCULAR EL COSTE
		Node<T> nuevo = new Node<>(elem);
		if (this.isEmpty()) {
			nuevo.next = nuevo;
			nuevo.prev = nuevo;
			first=nuevo;
		}
		else if (first.next != null) {
			first.prev.next = nuevo;
			nuevo.prev = first.prev;
			first.prev = nuevo;
			nuevo.next = first;
		}
		else {
			first.next = nuevo;
			first.prev = nuevo;
			nuevo.next = first;
			nuevo.prev = first;
		}
		count++;
	}
	
	public void addAfter(T elem, T target) {
	// A�ade elem detr�s de otro elemento concreto, target,  que ya se encuentra en la lista
		// �COMPLETAR OPCIONAL!
		Node<T> act = first;
		Node<T> nuevo = new Node<>(elem);
		if (this.isEmpty()) {
			addToFront(elem);
			count++;
		}
		else {
			boolean enc = false;
			boolean vuelta = false;
			while (!enc && !vuelta) {
				if (act.data == target) {
					enc = true;
					nuevo.next = act.next;
					nuevo.prev = act;
					act.next.prev = nuevo;
					act.next = nuevo;
					count++;
				}
				else if (act.next.equals(first)) {
					vuelta = true;
					System.out.println("No existe el elemento target, por lo que no se ha a�adido");
				}
				else {
					act = act.next;
				}
			}
		}
	}

}
