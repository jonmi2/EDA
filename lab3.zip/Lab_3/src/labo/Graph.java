package labo;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Graph {
		HashMap<String, Integer> th = new HashMap<String, Integer>(); //String=key y Integer=Value
	    String[] keys;
	    ArrayList<Integer>[] adjList;
	      
	    HashMapAc MapAc = HashMapAc.getMiMapa();
	    HashMapPeli MapPe = HashMapPeli.getMiMapa();
	  	        
		public void crearGrafo(HashMapAc MapAc, HashMapPeli MapPe)
		{
			// Post: crea el grafo desde la lista de peliculas
			//       Los nodos son nombres de actores/actrices		
			
	            // Paso 1: llenar �th�
	            // COMPLETAR C�DIGO
			
			MapAc.rellenarMapa(th);
			
			
	            // Paso 2: llenar �keys�
			keys = new String[th.size()];
			for (String k: th.keySet())
			{
				keys[th.get(k)] = k;
			}

	            // Paso 3: llenar �adjList�
	            // COMPLETAR C�DIGO
			adjList = new ArrayList[th.size()];
			
			for (int x=0; x<th.size(); x++)
			{
				adjList[x]=new ArrayList<Integer>();
			}
			
			MapPe.rellenarAdjList(th, adjList);		
		}
		
		
		public void print(){
		   for (int i = 0; i < adjList.length; i++)
		   {
			System.out.print("Element: " + i + " " + keys[i] + " --> ");
			for (int k: adjList[i]) 
			{
				System.out.print(keys[k] + " ### ");
			}
			System.out.println();
		   }
		}
		
		public boolean estanConectados(String a1, String a2)
		{
			if (!th.containsKey(a2) && !th.containsKey(a1))
			{
				System.out.println("No est�n conectados ya que ninguno de los dos actores est� en nuestros datos");
				return false;
			}
			else if (!th.containsKey(a2) || !th.containsKey(a1))
			{
				System.out.println("No est�n conectados ya que alguno de los dos actores no est� en nuestros datos");
				return false;
			}
			else if(a1==a2){
				System.out.println("Son la misma persona, por lo que si estan conectados");
				return true;
			}
			else
			{
				Queue<Integer> porExaminar = new LinkedList<Integer>();
				int pos1 = th.get(a1);
				int pos2 = th.get(a2);
				boolean enc = false;
				boolean[] examinados = new boolean[th.size()];
				porExaminar.add(pos1);
				while (!enc && !porExaminar.isEmpty())
				{
					int act = porExaminar.remove();
					if (act==pos2)//se termina y devolvemos que s� est�n conectados
					{
						enc=true;
					}
					else
					{
						examinados[act]=true;
						ArrayList<Integer> vecinosact = adjList[act];
						for(int i=0; i<vecinosact.size(); i++)
						{
							if (!examinados[vecinosact.get(i)] && !porExaminar.contains(vecinosact.get(i)))
							{
								porExaminar.add(vecinosact.get(i));
							}
						}
					}
				}
				return enc;
			}
		}
		
		public ArrayList<String> Conexion(String a1, String a2) 
		{
		    ArrayList<String> rdo = new ArrayList<String>();
		    int[] backP = new int[th.size()];
		    if (!th.containsKey(a2) && !th.containsKey(a1)) 
		    {
		        System.out.println("No est�n conectados ya que ninguno de los dos actores est� en nuestros datos");
		        return rdo;
		    } 
		    else if (!th.containsKey(a2) || !th.containsKey(a1)) 
		    {
		        System.out.println("No est�n conectados ya que alguno de los dos actores no est� en nuestros datos");
		        return rdo;
		    } 
		    else if (!estanConectados(a1, a2)) 
		    {
		        System.out.println("No se va da devolver nada ya que no est�n conectados");
		        return rdo;
		    } 
		    else if(a1==a2) {
		    	rdo.add(a2);
		    	return rdo;
		    }
		    else 
		    {
		        Queue<Integer> porExaminar = new LinkedList<Integer>();
		        int pos1 = th.get(a1);
		        int pos2 = th.get(a2);
		        boolean enc = false;
		        boolean[] examinados = new boolean[th.size()];
		        porExaminar.add(pos1);
		        backP[pos1] = -1;
		        while (!enc && !porExaminar.isEmpty()) 
		        {
		            int act = porExaminar.remove();
		            if (act == pos2) // se termina y devolvemos que s� est�n conectados
		            {
		                enc = true;
		            } 
		            else 
		            {
		                examinados[act] = true;
		                ArrayList<Integer> vecinosact = adjList[act];
		                for (int i = 0; i < vecinosact.size(); i++) 
		                {
		                    if (!examinados[vecinosact.get(i)] && !porExaminar.contains(vecinosact.get(i))) 
		                    {
		                        porExaminar.add(vecinosact.get(i));
		                        backP[vecinosact.get(i)] = act;
		                    }
		                }
		            }
		        }

		        int i = pos2;
		        while (i != -1 && backP[i] != -1) {
		            rdo.add(keys[i]);
		            i = backP[i];
		        }
		        rdo.add(keys[pos1]); // Agregar el nodo inicial al principio
		        Collections.reverse(rdo); // Invertir la lista para que est� en el orden correcto
		        return rdo;
		    }
		}

}

