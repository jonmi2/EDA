package labo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;


public class HashMapAc 
{
	
    private HashMap<String,Actor> mapa;//String=key y Actor=Value
    private static HashMapAc miMapa = null;

   
    private HashMapAc()
    {
        mapa=new HashMap<String,Actor>();
    }

   

    
    public static HashMapAc getMiMapa()
    {
        if(miMapa==null)
        {
            miMapa=new HashMapAc();
        }
        return miMapa;
    }
    
    public boolean esta(Actor a)
    {
    	if (this.mapa.containsKey(a.getNombre()))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    public void anadir(Actor a)
    {
    	if (esta(a)==false)
    	{
    		this.mapa.put(a.getNombre(), a);
    	}
    }
    
    public void anadirpeliaact(Pelicula p, Actor a)
    {
    	this.mapa.get(a.getNombre()).anadirpeliaact(p);
    }
    
    
    public boolean esta(String nAct)
    {
    	if (this.mapa.containsKey(nAct))
    	{
    		return true;
    	}
    	else 
    	{
    		return false;
    	}
    }
    

	public void rellenarMapa(HashMap<String, Integer> th) 
	{
		int i = 0;
		for (String nombreActor : mapa.keySet()) 
    	{
            th.put(nombreActor, i);
			i++;
        }
	}




	public Actor getActor(String ac) 
	{
		return this.mapa.get(ac);
	}
    
    
}
