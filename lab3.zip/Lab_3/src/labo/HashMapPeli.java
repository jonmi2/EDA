package labo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class HashMapPeli 
{


    private HashMap<String,Pelicula> mapa;//String=key y Pelicula=Value
    private static HashMapPeli miMapa = null;

   
    private HashMapPeli()
    {
        mapa=new HashMap<String,Pelicula>();
    }

   

    
    public static HashMapPeli getMiMapa()
    {
        if(miMapa==null)
        {
            miMapa=new HashMapPeli();
        }
        return miMapa;
    }
    
    public boolean esta(Pelicula p)
    {
    	if (this.mapa.containsKey(p.getNombre()))
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    public void anadir(Pelicula p)
    {
    	if (esta(p)==false)
    	{
    		this.mapa.put(p.getNombre(), p);
    	}
    }
    
    public boolean esta(String nPeli)
    {
    	if (this.mapa.containsKey(nPeli))
    	{
    		return true;
    	}
    	else 
    	{
    		return false;
    	}
    }
    
    public Pelicula getP(String nPeli)
    {
    	return this.mapa.get(nPeli);
    }
    
    public void anadiractapeli(Actor a,Pelicula p)
    {
    	this.mapa.get(p.getNombre()).anadiractapeli(a);
    }
    
	public void rellenarAdjList(HashMap<String, Integer> th, ArrayList<Integer>[] adjList) 
	{
		for (String nombrePeli : mapa.keySet())
		{
			
			Pelicula p = mapa.get(nombrePeli);
			ListaActores acts = p.getActores();
			for (int i=0; i<acts.length(); i++)
			{
				int aId = th.get(acts.get(i).getNombre());
				ArrayList<Integer> compas = adjList[aId];
				for (int j=0; j<acts.length(); j++)
				{
					if (i!=j)
					{
						int compaID = th.get(acts.get(j).getNombre());
						if(!compas.contains(compaID))
						{
							compas.add(compaID);
						}
					}
				}
			}
		}
	}
}
