package labo;

import java.util.ArrayList;
import java.util.Scanner;

public class Menu 
{
	private static Menu miMenu = new Menu();
	
	private Menu() {}
	
	public static Menu getMenu() 
	{
		return miMenu;
	}
	
	public void showMenu()
	{
		datos miDatos = datos.getDatos();          
		Graph grafo = new Graph();
		HashMapAc mapAc = HashMapAc.getMiMapa();
		HashMapPeli mapP = HashMapPeli.getMiMapa();
        Scanner sn=new Scanner(System.in);
        boolean exit=false;
        int opcion; 
        while(!exit)
        {
        	System.out.println("\n----------------------------------------------------------------------------------------------------------------");
            System.out.println("\t\t Menu Principal \n");
            System.out.println("Seleccione una de las siguientes opciones:\n");
            System.out.println("0. Cargar los datos del fichero (HAY QUE HACERLO ANTES DE HACER NADA)");
            System.out.println("1. Comprobar si hay conexi�n entre dos actores");
            System.out.println("2. Imprimir la conexion entre dos actores");               
            System.out.println("3. Finalizar Programa");
            System.out.print("TU ELECCI�N---> ");
            opcion=sn.nextInt();

            switch (opcion)
            {
            	case 0:            		
       			 	System.out.println("Vamos a cargar los datos.");
            		miDatos.cargarLista();     		
            		grafo.crearGrafo(mapAc, mapP);
            		break;
                case 1:
                	Scanner sc2 = new Scanner(System.in);               	
            		System.out.println("Vamos a comprobar si existe la conexion entre 2 actores.");
            		System.out.println("Ingresa un nombre: "); 
                    String Act1 = sc2.nextLine();
                    Scanner sc3 = new Scanner(System.in);   
                    System.out.println("Ingresa otro nombre: "); 
                    String Act2 = sc3.nextLine();
                    if (grafo.estanConectados(Act1, Act2))
                    {
                    	System.out.println("Los actores "+Act1+" y "+Act2+" SI est�n conectados");
                    }
                    else
                    {
                    	System.out.println("Los actores "+Act1+" y "+Act2+" NO est�n conectados");
                    }    	                   
                    break;
                case 2:
                	Scanner sc4 = new Scanner(System.in);               	
            		System.out.println("Vamos a imprimir la conexion entre 2 actores (en caso de que est�n conectados).");
            		System.out.println("Ingresa un nombre: "); 
                    String a1 = sc4.nextLine();
                    Scanner sc5 = new Scanner(System.in);   
                    System.out.println("Ingresa otro nombre: "); 
                    String a2 = sc5.nextLine();
                    if (!grafo.estanConectados(a1, a2))
                    {
                    	System.out.println("No vamos a devolver ninguna conexion ya que los actores "+a1+" y "+a2+" NO est�n conectados.");
                    }
                    else
                    {
                    	System.out.println("Los actores " +a1+" y "+a2+ " si est�n conectados y esta es su conexi�n: ");
                    	ArrayList<String> rdo = grafo.Conexion(a1, a2);
                		System.out.println(rdo);
                    }	
                    break;
                case 3:
                	System.out.println("Se cierra el programa");
                	exit=true;
                    break;
                default:
                	System.out.println("Solo numeros del 0 al 3\n");
                }
            
            }
        sn.close();
	}
}
