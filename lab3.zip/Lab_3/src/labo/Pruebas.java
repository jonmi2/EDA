package labo;

import java.util.ArrayList;

public class Pruebas 
{
	public static void main(String[] args) 
	{
		datos miDatos = datos.getDatos();         
		miDatos.cargarLista();
		HashMapAc MapAc = HashMapAc.getMiMapa();
		HashMapPeli MapPe = HashMapPeli.getMiMapa();
		Graph grafo =new Graph();
		grafo.crearGrafo(MapAc, MapPe); 
		
		System.out.println();
		System.out.println("Estan conectados Anatoly Gushchin y Aglaya Shilovskaya?. Deber�a decir TRUE, y dice........");
		System.out.println(grafo.estanConectados("Anatoly Gushchin", "Aglaya Shilovskaya"));
		
		System.out.println();
		System.out.println("Estan conectados Aglaya Shilovskaya y Nastasya Samburskaya?. Deber�a decir TRUE, y dice........");
		System.out.println(grafo.estanConectados("Aglaya Shilovskaya", "Nastasya Samburskaya"));
		
		System.out.println();
		System.out.println("Estan conectados Aglaya Shilovskaya y aaaaa?. Deber�a decir FALSE (porq UNO no est�), y dice........");
		System.out.println(grafo.estanConectados("Aglaya Shilovskaya", "aaaa"));
		
		System.out.println();
		System.out.println("Estan conectados asasdas y duuuuuodo?. Deber�a decir FALSE (porq los DOS no est�n), y dice........");
		System.out.println(grafo.estanConectados("dvdfdf", "duuuuudo"));
		
		System.out.println("----------------------------------------------------------------------------------------");
		
		System.out.println();
		System.out.println("Conexion entre Anatoly Gushchin y Aglaya Shilovskay?. Devuelve........");
		ArrayList<String> rdo = grafo.Conexion("Anatoly Gushchin", "Aglaya Shilovskaya");
		System.out.println(rdo);
		
		System.out.println();
		System.out.println("Conexion entre Aglaya Shilovskaya y Nastasya Samburskaya. Devuelve........");
		ArrayList<String> rdo1 = grafo.Conexion("Aglaya Shilovskaya", "Nastasya Samburskaya");
		System.out.println(rdo1);
		
		System.out.println();
		System.out.println("Conexion entre Babita y Bradley Cooper. NO HAY CONEXI�N y devuelve........");
		ArrayList<String> rdo2 = grafo.Conexion("Babita", "Bradley Cooper");
		System.out.println(rdo2);
		
		System.out.println();
		System.out.println("Conexi�n entre Aglaya Shilovskaya y aaaaa?. NO HAY CONEXI�N (porq UNO no est�) y devuelvee� .......");
		ArrayList<String> rdo3 = grafo.Conexion("Aglaya Shilovskaya","aaaaa");
		System.out.println(rdo3);
		
		System.out.println();
		System.out.println("Conexion entre asasdas y duuuuuodo?. NO HAY CONEXI�N (porq los DOS no est�n) y devuelve........");
		ArrayList<String> rdo4 = grafo.Conexion("ASDFGHJKUYTGBn", "AFVGRGTJa");
		System.out.println(rdo4);
		
		System.out.println();
		System.out.println("Conexion entre Aglaya Shilovskaya y Aglaya Shilovskaya. Son la misma persona, y devuelve........");
		ArrayList<String> rdo5 = grafo.Conexion("Aglaya Shilovskaya", "Aglaya Shilovskaya");
		System.out.println(rdo5);
		
		
		//estas pruebas son para utilizrlas con el fichero de texto peque�o que nos hemos inventado
		/*
		System.out.println();
		System.out.println("VAMOS A IMPRMIR grafo entero");
		grafo.print();
		
		System.out.println();
		System.out.println("Estan conectados darell y quevedp?. Deber�a decir TRUE, y dice........");
		System.out.println(grafo.estanConectados("darell", "quevedp"));
		
		System.out.println();
		System.out.println("Estan conectados Leo Messi y Jon Miraz?. Deber�a decir TRUE, y dice........");
		System.out.println(grafo.estanConectados("Leo Messi", "Jon Miraz"));
		
		System.out.println();
		System.out.println("Estan conectados jorge y dodo?. Deber�a decir TRUE, y dice........");
		System.out.println(grafo.estanConectados("jorge", "dodo"));
		
		System.out.println();
		System.out.println("Estan conectados bad y mol?. Deber�a decir TRUE, y dice........");
		System.out.println(grafo.estanConectados("bad", "mol"));
		
		System.out.println();
		System.out.println("Estan conectados mikell y quevedp?. Deber�a decir TRUE, y dice........");
		System.out.println(grafo.estanConectados("mikell", "quevedp"));
		
		System.out.println();
		System.out.println("Estan conectados bad y abhir?. Deber�a decir FALSE, y dice........");
		System.out.println(grafo.estanConectados("bad", "abhir"));
		
		System.out.println();
		System.out.println("Estan conectados dembele y abhir?. Deber�a decir FALSE, y dice........");
		System.out.println(grafo.estanConectados("dembele", "abhir"));
		
		System.out.println();
		System.out.println("Estan conectados grisman y aaaaa?. Deber�a decir FALSE (porq UNO no est�), y dice........");
		System.out.println(grafo.estanConectados("grisman", "aaaa"));
		
		System.out.println();
		System.out.println("Estan conectados asasdas y duuuuuodo?. Deber�a decir FALSE (porq los DOS no est�n), y dice........");
		System.out.println(grafo.estanConectados("dvdfdf", "duuuuudo"));
		
		System.out.println("----------------------------------------------------------------------------------------");
		
		System.out.println();
		System.out.println("Conexion de asasdas y duuuuuodo?. Deber�a decir FALSE (porq los DOS no est�n), y dice........");
		System.out.println(grafo.Conexion("dvdfdf", "duuuuudo"));
		
		System.out.println();
		System.out.println("Conexion grisman y aaaaa?. Deber�a decir FALSE (porq UNO no est�), y dice........");
		System.out.println(grafo.Conexion("grisman", "aaaa"));
		
		System.out.println();
		System.out.println("Conexion jorge y dodo?  ......... TIENE Q SER jorge-dodo");
		ArrayList<String> rdo =grafo.Conexion("jorge", "dodo");
		System.out.println(rdo);
		
		System.out.println();
		System.out.println("Conexion darell y quevedp?........ TIENE Q SER darell-cruzi-quevedp");
		ArrayList<String> rdo1 =grafo.Conexion("darell", "quevedp");
		System.out.println(rdo1);
		
		System.out.println();
		System.out.println("Conexion mikell y quevedp?........ TIENE Q SER mikell-darell-cruzzi-quevedp");
		ArrayList<String> rdo3 =grafo.Conexion("mikell", "quevedp");
		System.out.println(rdo3);
		
		System.out.println();
		System.out.println("Conexion josu y dembele?........ TIENE Q SER josu-cristiano-grisman-dembele");
		ArrayList<String> rdo4 =grafo.Conexion("josu", "dembele");
		System.out.println(rdo4);
		
		System.out.println();
		System.out.println("Conexion ozuna y quevedp?........ TIENE Q SER ozuna-darell-cruzzi-quevedp");
		ArrayList<String> rdo5 =grafo.Conexion("ozuna", "quevedp");
		System.out.println(rdo5);
		
		System.out.println();
		System.out.println("Conexion dembele y abhir?......... TIENE Q SER FALSE");
		ArrayList<String> rdo2 = grafo.Conexion("dembele", "abhir");
		System.out.println(rdo2);
		
		*/
	}	
}
