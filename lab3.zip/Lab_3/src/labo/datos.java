package labo;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class datos 
{
	
	private static datos miDatos = new datos();
	
	private datos()
	{
	}
	
	
	
	public static datos getDatos()
	{
		return datos.miDatos;
	}
			
	
	
		
	
	
	public void cargarLista()//con todos los datos
		{
			for (int ano=1970; ano<=2023; ano++)
			{
					String ruta="C:\\ECLIPSE_JAVA\\workspace\\EDAlab3\\src\\movies-dir\\movies-dir\\actors_and_films_"+ano+".txt";
					try
					{
						 Scanner entrada = new Scanner(new FileReader(ruta)); 
						 String linea; 
						 while (entrada.hasNext()) 
						 {
							 linea = entrada.nextLine();
							 String datos[] = linea.split("\\s+###\\s+");
				             String actor = datos[1];	
				             String pelicula = datos[3];
				             Actor a = new Actor(actor);             
				             Pelicula p = new Pelicula(pelicula,ano);
				             HashMapAc MapAc = HashMapAc.getMiMapa();
				             HashMapPeli MapPe = HashMapPeli.getMiMapa();
				             if (MapAc.esta(a)==false && MapPe.esta(p)==false)
				             {
				            	 a.anadirpeliaact(p);
				            	 p.anadiractapeli(a);
				            	 MapAc.anadir(a);
				            	 MapPe.anadir(p);
				             }
				             else if (MapAc.esta(a)==true && MapPe.esta(p)==false)
				             {
				            	 p.anadiractapeli(a);
				            	 MapAc.anadirpeliaact(p, a);
				            	 MapPe.anadir(p);
				             }
				             else if (MapAc.esta(a)==false && MapPe.esta(p)==true)
				             {
				            	 a.anadirpeliaact(p);
				            	 MapAc.anadir(a);
				            	 MapPe.anadiractapeli(a,p);
				            	 
				             }
				             else if (MapAc.esta(a)==true && MapPe.esta(p)==true)
				             {
				            	 MapAc.anadirpeliaact(p, a);
				            	 MapPe.anadiractapeli(a,p);
				             }	             	                         
						 }
						 entrada.close();
					}
				catch(IOException e) 
					{
						
						System.out.println("No se pueden cargar los datos ya que no existe el archivo");
					}
					}
			
		}
	
	
}

