package labo;

import java.util.ArrayList;
import java.util.Iterator;


public class ListaPelis 
{
	private ArrayList<Pelicula> lista;
	
	
	public ListaPelis()
	{
		this.lista=new ArrayList<Pelicula>();
	}
	 
	public Iterator<Pelicula> getIterador()
	{
		return lista.iterator();
	}
	
	public boolean esta(String pPeli)
	{
		Iterator<Pelicula> itr = this.getIterador();
		boolean enc = false;
		Pelicula p = null;
		while (enc==false && itr.hasNext())
		{
			p=itr.next();
			if(p.getNombre().equals(pPeli))
			{
				enc=true;
			}
			else
			{
				enc=false;
			}
		}
		return enc;
	}
	
	
	
	
	public void anadir(Pelicula pPeli)
	{
		if (this.esta(pPeli.getNombre())==false)
		{
			this.lista.add(pPeli);
		}
	}
	
	
	
	public void anadiractapeli(String pNom, Actor pActor)
	{
		Iterator<Pelicula> itr = this.getIterador();
		boolean enc = false;
		Pelicula p = null;
		while (enc==false && itr.hasNext())
		{
			p=itr.next();
			if(p.getNombre().equals(pNom))
			{
				enc=true;
			}			
		}
		if (enc==true)
		{
			p.anadiractapeli(pActor);
		}
	}

	
}
