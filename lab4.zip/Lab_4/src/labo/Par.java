package labo;

public class Par 
{
	String actor;
	Double pageRank;
	
	public Par (String ac, Double pg)
	{
		this.actor=ac;
		this.pageRank=pg;
	}
}
