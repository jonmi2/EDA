package labo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Pruebas 
{
	public static void main(String[] args) 
	{
		datos miDatos = datos.getDatos();         
		miDatos.cargarLista();
		HashMapAc MapAc = HashMapAc.getMiMapa();
		HashMapPeli MapPe = HashMapPeli.getMiMapa();
		Graph grafo =new Graph();
		grafo.crearGrafo(MapAc, MapPe); 
		

		System.out.println("----Vamos a hacer las pruebas con unos datos inventados para demostrar que funciona, ya que imprimir todos los datos que nos han dado es imposible----");
		
		System.out.println("----imprimir grafo----");
		grafo.print();
		System.out.println("");
		
		System.out.println("----imprimir th----");
		System.out.println(grafo.th.toString());
		System.out.println("");
		
		System.out.println("----imprimir adjlist----");
		for (int i=0; i<grafo.adjList.length; i++)
		{
			ArrayList<Integer> aa = grafo.adjList[i];
			Iterator<Integer> itr = aa.iterator();			
			System.out.print("el actor " + grafo.keys[i] + " esta relacionado con");
			while (itr.hasNext())
			{
				int a = itr.next();
				System.out.print(" " + grafo.keys[a] + "  ");
			}
			System.out.println();
		}
		System.out.println("");
		
		
		System.out.println("----prueba page rank----");
		System.out.println("tiene que decir lo siguiente:");
		System.out.println("A = 0,3667");
		System.out.println("B = 0,1414");
		System.out.println("C = 0,2459");
		System.out.println("D = 0,2459");
		System.out.println("y dice:");
		HashMap<String, Double> resul = grafo.pageRank();
		for (String nom : resul.keySet())
		{								
			double ahora = resul.get(nom);					
			System.out.println("valor del "+nom + "   es:    " + ahora);
		}
		System.out.println("");
		
		System.out.println("----prueba buscarActores----");
		System.out.println("tiene que decir lo siguiente:");
		System.out.println("<A , 0,3667>");
		System.out.println("<C , 0,2459>");
		System.out.println("<D , 0,2459>");
		System.out.println("<B , 0,1414>");
		System.out.println("y dice:");
		ArrayList<Par> rdo = new ArrayList<Par>();
		ArrayList<String> actores = new ArrayList<String>();
		actores.add("C");
		actores.add("A");
		actores.add("B");
		actores.add("D");
		rdo = grafo.buscarActores(actores);
		Iterator<Par> itr = rdo.iterator();
		Par p = null;
		while (itr.hasNext())
		{
			p = itr.next();
			System.out.println("< "+p.actor+" , "+p.pageRank+" >");
		}		
	}	
}
