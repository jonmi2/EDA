module EDAlab3 {
	exports labo;
}